-- Simple Persistent Ground Groups (SPGG)
-- By A Glutton For Punishment (aka Kanelbolle)

env.info('-- SPGG - Loading Function for Save!')





function findIfValueInArray(whichArray, itemName)
		for currentIndex = 1, #whichArray do
			--if whichArray[currentIndex] == itemName then
			if string.match(itemName, '^' .. whichArray[currentIndex] .. '.*$') then
				
						--env.info('-- Found in '.. whichArray[currentIndex] ..' : ' .. itemName)
				
								--Sends true back if value exist
				return true
			end
		end
end

function findValue(whichArray, itemName)
		for currentIndex = 1, #whichArray do
			if whichArray[currentIndex] == itemName then
								--Sends true back if value exist
				return true
			end
		end
end




function save_time(time)
  local days = math.floor(time/86400)
  local hours = math.floor(math.mod(time, 86400)/3600)
  local minutes = math.floor(math.mod(time,3600)/60)
  local seconds = math.floor(math.mod(time,60))
  return string.format("%d_%02d_%02d_%02d",days,hours,minutes,seconds)
end










function spgg.save()

	env.info('-- ')
	env.info('-- SPGG - Running spgg.save()')

	_groupBlueCount = 0
	_groupRedCount = 0
	_soBlueCount = 0
	_soRedCount = 0
	_groupBlueSeaCount = 0
	_groupRedSeaCount = 0


	wFile = io.open(spgg.defaultDrive .. spgg.saveFilename, 'w')
	


	wFile:write('spgg = spgg or {}' .. '\n')
	
	wFile:write('spgg.bluegroups = spgg.bluegroups or {}' .. '\n')
	wFile:write('spgg.redgroups = spgg.redgroups or {}' .. '\n')
	
	wFile:write('spgg.bluestaticobj = spgg.bluestaticobj or {}' .. '\n')
	wFile:write('spgg.redstaticobj = spgg.redstaticobj or {}' .. '\n')
	
	wFile:write('spgg.blueseagroups = spgg.blueseagroups or {}' .. '\n')
	wFile:write('spgg.redseagroups = spgg.redseagroups or {}' .. '\n')
	
	
	--Backup save file
	local _timesave = timer.getTime()
	local _dhmsTimeleft = save_time(_timesave)
	wBackupFile = io.open(spgg.defaultDrive .. "Backup-Saves\\" .. spgg.saveFilename .. "_inGameTime_" .. _dhmsTimeleft .. '.lua', 'w')
	
	wBackupFile:write('spgg = spgg or {}' .. '\n')
	wBackupFile:write('spgg.bluegroups = spgg.bluegroups or {}' .. '\n')
	wBackupFile:write('spgg.redgroups = spgg.redgroups or {}' .. '\n')
	wBackupFile:write('spgg.bluestaticobj = spgg.bluestaticobj or {}' .. '\n')
	wBackupFile:write('spgg.redstaticobj = spgg.redstaticobj or {}' .. '\n')
	wBackupFile:write('spgg.blueseagroups = spgg.blueseagroups or {}' .. '\n')
	wBackupFile:write('spgg.redseagroups = spgg.redseagroups or {}' .. '\n')

	

	-----------------------------------
	-- Get Blue Coalition Forces	-------------------
	-----------------------------------
	for i, gp in pairs(coalition.getGroups(2, 2)) do

		local _GpName = Group.getName(gp)
		
		if _GpName ~= nil then
		
				if (Group.getByName(_GpName) and Group.getByName(_GpName):getSize() > 0) and (Group.isExist(gp) == true) then
		
					
					if findIfValueInArray(_tblExcludeGroupName, _GpName) then
					
						-- Do nothing if it is excluded!
						
						if (_ShowEnvinfo == true) then
							env.info('-- SPGG - Excluded Blue Group: ' .. _GpName)
						end
						
					else
						
						local _gpUnitSize = Group.getByName(_GpName):getSize()
						
						getGroupAndSave(2, _GpName, _gpUnitSize)
						
					
					end -- if (findValue(_tblExcludeGroupName, _GpName) ~= nil) then
		
		
				end
		
		
		end -- if _GpName =~ nil then
		
		
	end -- for i, gp in pairs(coalition.getGroups(2,2)) do







	-----------------------------------
	-- Get Red Coalition Forces	-------------------
	-----------------------------------
	for i, gp in pairs(coalition.getGroups(1, 2)) do

		local _GpName = Group.getName(gp)
		
		if _GpName ~= nil then
		
				if (Group.getByName(_GpName) and Group.getByName(_GpName):getSize() > 0) and (Group.isExist(gp) == true) then
		
		
		
					if findIfValueInArray(_tblExcludeGroupName, _GpName) then
					
						-- Do nothing if it is excluded!
						if (_ShowEnvinfo == true) then
							env.info('-- SPGG - Excluded Red Group: ' .. _GpName)
						end
						
					else
						
						local _gpUnitSize = Group.getByName(_GpName):getSize()
						
						getGroupAndSave(1, _GpName, _gpUnitSize)
						
					
					end -- if (findValue(_tblExcludeGroupName, _GpName) ~= nil) then
		
		
				end
		
		
		end -- if _GpName =~ nil then
		
		
	end -- for i, gp in pairs(coalition.getGroups(2,2)) do








	-----------------------------------
	-- Static Blue Objects	-------------------
	-----------------------------------

	

	for i, so in pairs(coalition.getStaticObjects(2)) do


	local _SoName = StaticObject.getName(so)
	local _SoType = so:getTypeName()
 
 
 
		
		if (StaticObject.getByName(_SoName)) and (StaticObject.isExist(so)) then
 
			--trigger.action.outText("Exsist : " .._SoName , 10)
		
			if ( findValue(_tblIncludeStaticObjectType, _SoType)) then
		
				if (_ShowEnvinfo == true) then
					env.info('-- SPGG - Found Blue Static Object : '.. _SoName.. ' - Type : ' .. _SoType)
				end
				
		
				if ( findIfValueInArray(_tblExcludeGroupName, _SoName)) then
				
					if (_ShowEnvinfo == true) then
						env.info('-- SPGG - Excluded Blue Static Object - On Excluded Name List: ' .. _SoName.. ' - Type : ' .. _SoType)
					end
					
				else --if (_SoName == string.match(_SoName, '^Deployed FOB.*$')) then
				
					if (_ShowEnvinfo == true) then
						env.info('-- SPGG - Saving Blue Static Object: '.. _SoName .. ' - Type : ' .. _SoType)
					end
					
						
					getObjectAndSave(2, _SoName)
					
					
					
				end
			end
		
		
		
		end

	end -- for i, so in pairs(coalition.getStaticObjects(1)) do



	-----------------------------------
	-- Static Red Objects	-------------------
	-----------------------------------


	
	
	for i, so in pairs(coalition.getStaticObjects(1)) do


	local _SoName = StaticObject.getName(so)
	local _SoType = so:getTypeName()
 
 
 
		
		if (StaticObject.getByName(_SoName)) and (StaticObject.isExist(so)) then
 

			
			if ( findValue(_tblIncludeStaticObjectType, _SoType)) then
		
				if (_ShowEnvinfo == true) then
					env.info('-- SPGG - Found Red Static Object : '.. _SoName.. ' - Type : ' .. _SoType)
				end
				
		
				if ( findIfValueInArray(_tblExcludeGroupName, _SoName)) then
				
					if (_ShowEnvinfo == true) then
						env.info('-- SPGG - Excluded Red Static Object - On Excluded Name List: ' .. _SoName.. ' - Type : ' .. _SoType)
					end
					

				else
				
					if (_ShowEnvinfo == true) then
						env.info('-- SPGG - Saving Red Static Object: '.. _SoName .. ' - Type : ' .. _SoType)
					end
								
							
					getObjectAndSave(1, _SoName)
					
					
					
				end
			end
		
			
		
		end

	end -- for i, so in pairs(coalition.getStaticObjects(1)) do





	-----------------------------------
	-- Sea Blue Groups	---------------
	-----------------------------------
	for i, gp in pairs(coalition.getGroups(2, 3)) do

		local _GpName = Group.getName(gp)
		
		if _GpName ~= nil then
		
				if (Group.getByName(_GpName) and Group.getByName(_GpName):getSize() > 0) and (Group.isExist(gp) == true) then
		
					
					if findIfValueInArray(_tblExcludeGroupName, _GpName) then
					
						-- Do nothing if it is excluded!
						
						if (_ShowEnvinfo == true) then
							env.info('-- SPGG - Excluded Blue Sea Group: ' .. _GpName)
						end
						
					else
						
						local _gpUnitSize = Group.getByName(_GpName):getSize()
						
						getSeaGroupAndSave(2, _GpName, _gpUnitSize)
						
					
					end -- if (findValue(_tblExcludeGroupName, _GpName) ~= nil) then
		
		
				end
		
		
		end -- if _GpName =~ nil then
		
		
	end -- for i, gp in pairs(coalition.getGroups(2,2)) do







	-----------------------------------
	-- Sea Red Groups	---------------
	-----------------------------------
	for i, gp in pairs(coalition.getGroups(1, 3)) do

		local _GpName = Group.getName(gp)
		
		if _GpName ~= nil then
		
				if (Group.getByName(_GpName) and Group.getByName(_GpName):getSize() > 0) and (Group.isExist(gp) == true) then
		
		
		
					if findIfValueInArray(_tblExcludeGroupName, _GpName) then
					
						-- Do nothing if it is excluded!
						if (_ShowEnvinfo == true) then
							env.info('-- SPGG - Excluded Red Sea Group: ' .. _GpName)
						end
						
					else
						
						local _gpUnitSize = Group.getByName(_GpName):getSize()
						
						getSeaGroupAndSave(1, _GpName, _gpUnitSize)
						
					
					end -- if (findValue(_tblExcludeGroupName, _GpName) ~= nil) then
		
		
				end
		
		
		end -- if _GpName =~ nil then
		
		
	end -- for i, gp in pairs(coalition.getGroups(2,2)) do








	if (ctld ~= nil) then
		saveCtldTables()
	end


	wBackupFile:close()
	wBackupFile  = nil

	wFile:close()
	wFile = nil

end -- end of function SPGGSave(coalitionId)




function getObjectAndSave(coalitionId, soName)

	
		
	if coalitionId ~= nil then
		
		
		
		_sObject = StaticObject.getByName(soName)
		
		local _soType = _sObject:getTypeName()
		
		local _soDataTable = StaticObject.getDescByName(soName) 
		
		local _soCategory =  _soDataTable.category
		
		--env.info('-- SPGG :  Type: ' .. _soType .. ' - Category: ' .. _soDataTable.category)
		
		local _soCoord = _sObject:getPoint()
			
		local _sCoalition = _sObject:getCoalition()
		
		_soPoss = _sObject:getPosition()
		local _soHeading = math.atan2(_soPoss.x.z, _soPoss.x.x)
		
		local _country = _sObject:getCountry()
		
		if coalitionId == 1 then
		
			_soRedCount = _soRedCount +1 
		
			
			
			wFile:write('spgg.redstaticobj['.._soRedCount..'] = { ["obj"] = {} }' .. '\n')
	
			wFile:write('spgg.redstaticobj['.._soRedCount..'].obj[1] = { ["type"] = "' .. _soType .. '", ["category"] = "' .. _soCategory .. '", ["name"] = "' .. soName .. '", ["x"] = ' .. _soCoord.x .. ', ["y"] = ' .. _soCoord.z .. ', ["heading"] = ' .. _soHeading .. ', ["country"]= '.. _country ..', }' .. '\n')
		
		
			--Backup
			wBackupFile:write('spgg.redstaticobj['.._soRedCount..'] = { ["obj"] = {} }' .. '\n')
			wBackupFile:write('spgg.redstaticobj['.._soRedCount..'].obj[1] = { ["type"] = "' .. _soType .. '", ["category"] = "' .. _soCategory .. '", ["name"] = "' .. soName .. '", ["x"] = ' .. _soCoord.x .. ', ["y"] = ' .. _soCoord.z .. ', ["heading"] = ' .. _soHeading .. ', ["country"]= '.. _country ..', }' .. '\n')
				
		
		elseif coalitionId == 2 then
		
			_soBlueCount = _soBlueCount +1
			
			
			wFile:write('spgg.bluestaticobj['.._soBlueCount..'] = { ["obj"] = {} }' .. '\n')
			
			wFile:write('spgg.bluestaticobj['.._soBlueCount..'].obj[1] = { ["type"] = "' .. _soType .. '", ["category"] = "' .. _soCategory .. '", ["name"] = "' .. soName .. '", ["x"] = ' .. _soCoord.x .. ', ["y"] = ' .. _soCoord.z .. ', ["heading"] = ' .. _soHeading .. ', ["country"]= '.. _country ..', }' .. '\n')


			--Backup
			wBackupFile:write('spgg.bluestaticobj['.._soBlueCount..'] = { ["obj"] = {} }' .. '\n')
			wBackupFile:write('spgg.bluestaticobj['.._soBlueCount..'].obj[1] = { ["type"] = "' .. _soType .. '", ["category"] = "' .. _soCategory .. '", ["name"] = "' .. soName .. '", ["x"] = ' .. _soCoord.x .. ', ["y"] = ' .. _soCoord.z .. ', ["heading"] = ' .. _soHeading .. ', ["country"]= '.. _country ..', }' .. '\n')


		
		end
	
		
	
	
	end


end








function getGroupAndSave(coalitionId, gpName, gpUnitSize)


	if coalitionId ~= nil then
	
		if coalitionId == 1 then
			
			_groupRedCount = _groupRedCount +1 

			wFile:write('spgg.redgroups['.._groupRedCount..'] = { ["groupname"] = "' ..gpName.. '", ["units"] = {} }' .. '\n')
			
			--backup
			wBackupFile:write('spgg.redgroups['.._groupRedCount..'] = { ["units"] = {} }' .. '\n')
	
		end
	
	
		if coalitionId == 2 then
			
			_groupBlueCount = _groupBlueCount +1 

			wFile:write('spgg.bluegroups['.._groupBlueCount..'] = { ["groupname"] = "' ..gpName.. '", ["units"] = {} }' .. '\n')
			
			--Backup
			wBackupFile:write('spgg.bluegroups['.._groupBlueCount..'] = { ["units"] = {} }' .. '\n')
	
		end




		for uIndex = 1, gpUnitSize do
			
		
		
		
			local _Group = Group.getByName(gpName)
		
			
			local _unitName = _Group:getUnit(uIndex):getName()
		
			local _unit = Unit.getByName(_unitName)
			local _unitType = _unit:getTypeName()
			
			local _unitCoord = _unit:getPoint()
			
			local _coalition = _Group:getCoalition()
				
					
			_unitPoss = _unit:getPosition()
			local _unitHeading = math.atan2(_unitPoss.x.z, _unitPoss.x.x)
			
			
			local _country = _unit:getCountry()
			
		
			if coalitionId == 1 then
		
				if (_ShowEnvinfo == true) then
					env.info('-- SPGG - Saving Red unit: '.. _unitName .. ' - Type: ' .. _unitType .. ' - Coordinates X: ' .. _unitCoord.x .. ' - Y: ' .. _unitCoord.y .. ' - Z: ' .. _unitCoord.z .. ' - Heading: ' .. _unitHeading .. ' - Country: '.. _country)
				end
		
				wFile:write('spgg.redgroups['.._groupRedCount..'].units['..uIndex..'] = { ["type"] = "' .. _unitType .. '", ["name"] = "' .. _unitName .. '", ["skill"] = "Excellent", ["x"] = ' .. _unitCoord.x .. ', ["y"] = ' .. _unitCoord.z .. ', ["heading"] = ' .. _unitHeading .. ', ["playerCanDrive"] = true, ["country"]= '.. _country ..', }' .. '\n')
				
				--backup
				wBackupFile:write('spgg.redgroups['.._groupRedCount..'].units['..uIndex..'] = { ["type"] = "' .. _unitType .. '", ["name"] = "' .. _unitName .. '", ["skill"] = "Excellent", ["x"] = ' .. _unitCoord.x .. ', ["y"] = ' .. _unitCoord.z .. ', ["heading"] = ' .. _unitHeading .. ', ["playerCanDrive"] = true, ["country"]= '.. _country ..', }' .. '\n')
			
	
			
			elseif coalitionId == 2 then
		
				if (_ShowEnvinfo == true) then
					env.info('-- SPGG - Saving Blue unit: '.. _unitName .. ' - Type: ' .. _unitType .. ' - Coordinates X: ' .. _unitCoord.x .. ' - Y: ' .. _unitCoord.y .. ' - Z: ' .. _unitCoord.z .. ' - Heading: ' .. _unitHeading .. ' - Country: '.. _country)
				end
		
				wFile:write('spgg.bluegroups['.._groupBlueCount..'].units['..uIndex..'] = { ["type"] = "' .. _unitType .. '", ["name"] = "' .. _unitName .. '", ["skill"] = "Excellent", ["x"] = ' .. _unitCoord.x .. ', ["y"] = ' .. _unitCoord.z .. ', ["heading"] = ' .. _unitHeading .. ', ["playerCanDrive"] = true, ["country"]= '.. _country ..', }' .. '\n')
			
				--backup
				wBackupFile:write('spgg.bluegroups['.._groupBlueCount..'].units['..uIndex..'] = { ["type"] = "' .. _unitType .. '", ["name"] = "' .. _unitName .. '", ["skill"] = "Excellent", ["x"] = ' .. _unitCoord.x .. ', ["y"] = ' .. _unitCoord.z .. ', ["heading"] = ' .. _unitHeading .. ', ["playerCanDrive"] = true, ["country"]= '.. _country ..', }' .. '\n')
				
			else
		
				if (_ShowEnvinfo == true) then
					env.info('-- SPGG - Failed to get Group Coalition, Neutral? : '.. gpName)
					-- No Neutral units
				end
		
			end
			
		
		end -- for uIndex = 1, gpUnitSize do

		

	end -- end of if coalitionId ~= nil then




	

end -- function getGroupAndSave(gpName, gpUnitSize)






function getSeaGroupAndSave(coalitionId, gpName, gpUnitSize)


	if coalitionId ~= nil then
	
		if coalitionId == 1 then
			
			_groupRedSeaCount = _groupRedSeaCount +1 

			wFile:write('spgg.redseagroups['.._groupRedSeaCount..'] = { ["groupname"] = "' ..gpName.. '", ["units"] = {} }' .. '\n')
			
			--backup
			wBackupFile:write('spgg.redseagroups['.._groupRedSeaCount..'] = { ["units"] = {} }' .. '\n')
	
		end
	
	
		if coalitionId == 2 then
			
			_groupBlueSeaCount = _groupBlueSeaCount +1 

			wFile:write('spgg.blueseagroups['.._groupBlueSeaCount..'] = { ["groupname"] = "' ..gpName.. '", ["units"] = {} }' .. '\n')
			
			--Backup
			wBackupFile:write('spgg.blueseagroups['.._groupBlueSeaCount..'] = { ["units"] = {} }' .. '\n')
	
		end




		for uIndex = 1, gpUnitSize do
			
		
		
		
			local _Group = Group.getByName(gpName)
		
			
			local _unitName = _Group:getUnit(uIndex):getName()
		
			local _unit = Unit.getByName(_unitName)
			local _unitType = _unit:getTypeName()
			
			local _unitCoord = _unit:getPoint()
			
			local _coalition = _Group:getCoalition()
				
					
			_unitPoss = _unit:getPosition()
			local _unitHeading = math.atan2(_unitPoss.x.z, _unitPoss.x.x)
			
			
			local _country = _unit:getCountry()
			
		
			if coalitionId == 1 then
		
				if (_ShowEnvinfo == true) then
					env.info('-- SPGG - Saving Red Sea unit: '.. _unitName .. ' - Type: ' .. _unitType .. ' - Coordinates X: ' .. _unitCoord.x .. ' - Y: ' .. _unitCoord.y .. ' - Z: ' .. _unitCoord.z .. ' - Heading: ' .. _unitHeading .. ' - Country: '.. _country)
				end
		
				wFile:write('spgg.redseagroups['.._groupRedSeaCount..'].units['..uIndex..'] = { ["type"] = "' .. _unitType .. '", ["name"] = "' .. _unitName .. '", ["skill"] = "Excellent", ["x"] = ' .. _unitCoord.x .. ', ["y"] = ' .. _unitCoord.z .. ', ["heading"] = ' .. _unitHeading .. ', ["playerCanDrive"] = true, ["country"]= '.. _country ..', }' .. '\n')
				
				--backup
				wBackupFile:write('spgg.redseagroups['.._groupRedSeaCount..'].units['..uIndex..'] = { ["type"] = "' .. _unitType .. '", ["name"] = "' .. _unitName .. '", ["skill"] = "Excellent", ["x"] = ' .. _unitCoord.x .. ', ["y"] = ' .. _unitCoord.z .. ', ["heading"] = ' .. _unitHeading .. ', ["playerCanDrive"] = true, ["country"]= '.. _country ..', }' .. '\n')
			
	
			
			elseif coalitionId == 2 then
		
				if (_ShowEnvinfo == true) then
					env.info('-- SPGG - Saving Blue Sea unit: '.. _unitName .. ' - Type: ' .. _unitType .. ' - Coordinates X: ' .. _unitCoord.x .. ' - Y: ' .. _unitCoord.y .. ' - Z: ' .. _unitCoord.z .. ' - Heading: ' .. _unitHeading .. ' - Country: '.. _country)
				end
		
				wFile:write('spgg.blueseagroups['.._groupBlueSeaCount..'].units['..uIndex..'] = { ["type"] = "' .. _unitType .. '", ["name"] = "' .. _unitName .. '", ["skill"] = "Excellent", ["x"] = ' .. _unitCoord.x .. ', ["y"] = ' .. _unitCoord.z .. ', ["heading"] = ' .. _unitHeading .. ', ["playerCanDrive"] = true, ["country"]= '.. _country ..', }' .. '\n')
			
				--backup
				wBackupFile:write('spgg.blueseagroups['.._groupBlueSeaCount..'].units['..uIndex..'] = { ["type"] = "' .. _unitType .. '", ["name"] = "' .. _unitName .. '", ["skill"] = "Excellent", ["x"] = ' .. _unitCoord.x .. ', ["y"] = ' .. _unitCoord.z .. ', ["heading"] = ' .. _unitHeading .. ', ["playerCanDrive"] = true, ["country"]= '.. _country ..', }' .. '\n')
				
			else
		
				if (_ShowEnvinfo == true) then
					env.info('-- SPGG - Failed to get Sea Group Coalition, Neutral? : '.. gpName)
					-- No Neutral units
				end
		
			end
			
		
		end -- for uIndex = 1, gpUnitSize do

		

	end -- end of if coalitionId ~= nil then




	

end -- function getGroupAndSave(gpName, gpUnitSize)






-- Transfere FOB table to next session
function saveCtldTables()


	if (ctld ~= nil) then


		if (ctld.JTAC_dropEnabled ~= nil) then

			if (ctld.JTAC_dropEnabled == true) then
		
			
				-- ctld.JTAC_LIMIT_RED
				-- ctld.JTAC_LIMIT_BLUE
			
				-- ctld.droppedTroopsRED
				-- ctld.droppedTroopsBLUE
			
			
			
				if (_ShowEnvinfo == true) then
					env.info('-- SPGG - Saving JTAC limit parameters - RED :'.. ctld.JTAC_LIMIT_RED .. ' - BLUE: ' .. ctld.JTAC_LIMIT_BLUE)
				end
			
				if (ctld.JTAC_LIMIT_RED ~= nil) and (ctld.JTAC_LIMIT_BLUE ~= nil) then
					wFile:write('ctld.JTAC_LIMIT_RED = '.. ctld.JTAC_LIMIT_RED .. '\n')
					wFile:write('ctld.JTAC_LIMIT_BLUE = '.. ctld.JTAC_LIMIT_BLUE .. '\n')
				
					--backup
					wBackupFile:write('ctld.JTAC_LIMIT_RED = '.. ctld.JTAC_LIMIT_RED .. '\n')
					wBackupFile:write('ctld.JTAC_LIMIT_BLUE = '.. ctld.JTAC_LIMIT_BLUE .. '\n')
				end
				
			
			
			end	 -- end of if (ctld.JTAC_dropEnabled == true) then
		
		end	-- end of if (ctld.JTAC_dropEnabled ~= nil) then
	
	
		if (ctld.droppedTroopsRED ~= nil) and (ctld.droppedTroopsBLUE ~= nil) then

	
			wFile:write('spgg.redtroops = spgg.redtroops or {}' .. '\n')
			wFile:write('spgg.bluetroops = spgg.bluetroops or {}' .. '\n')
		
			--backup
			wBackupFile:write('spgg.redtroops = spgg.redtroops or {}' .. '\n')
			wBackupFile:write('spgg.bluetroops = spgg.bluetroops or {}' .. '\n')
	
	
			for i = 1, #ctld.droppedTroopsRED do
		
		
				
				wFile:write('spgg.redtroops['..i..'] = { ["name"] = "' .. ctld.droppedTroopsRED[i]..'" }' .. '\n')
			
				--backup
				wBackupFile:write('spgg.redtroops['..i..'] = { ["name"] = "' .. ctld.droppedTroopsRED[i]..'" }' .. '\n')
			
			end
		
			for i = 1, #ctld.droppedTroopsBLUE do
		
		
				wFile:write('spgg.bluetroops['..i..'] = { ["name"] = "' .. ctld.droppedTroopsBLUE[i]..'" }' .. '\n')
			
				--backup
				wBackupFile:write('spgg.bluetroops['..i..'] = { ["name"] = "' .. ctld.droppedTroopsBLUE[i]..'" }' .. '\n')
			
			end
	
	
	
		end -- end of if (ctld.droppedTroopsRED ~= nil) and (ctld.droppedTroopsBLUE ~= nil) then
		
		

		
		if (ctld.completeAASystems ~= nil) then
		
			spgg.SaveAASystemDetails()
		
		end -- end of if (ctld.completeAASystems ~= nil) then
		
	
	
		-- Save CTLD Logistic tables
		if (ctld.enabledFOBBuilding == true) then
		
		
			if (ctld.builtFOBS ~= nil) then
			
				wFile:write('spgg.builtFOBS = spgg.builtFOBS or {}' .. '\n')
				wBackupFile:write('spgg.builtFOBS = spgg.builtFOBS or {}' .. '\n')
			
				
				for i = 1, #ctld.builtFOBS do
		
					wFile:write('spgg.builtFOBS['..i..'] = { ["name"] = "' .. ctld.builtFOBS[i]..'" }' .. '\n')
				
					--backup
					wBackupFile:write('spgg.builtFOBS['..i..'] = { ["name"] = "' .. ctld.builtFOBS[i]..'" }' .. '\n')
			
				end -- end of: for i = 1, #ctld.builtFOBS do
			
			end -- end of: if (ctld.builtFOBS ~= nil) then
			
			
			
			if (ctld.logisticUnits ~= nil) then
			
				wFile:write('spgg.logisticUnits = spgg.logisticUnits or {}' .. '\n')
				wBackupFile:write('spgg.logisticUnits = spgg.logisticUnits or {}' .. '\n')
			
				
				for i = 1, #ctld.logisticUnits do
		
					wFile:write('spgg.logisticUnits['..i..'] = { ["name"] = "' .. ctld.logisticUnits[i]..'" }' .. '\n')
				
					--backup
					wBackupFile:write('spgg.logisticUnits['..i..'] = { ["name"] = "' .. ctld.logisticUnits[i]..'" }' .. '\n')
			
				end -- end of: for i = 1, #ctld.logisticUnits do
			
			end -- end of: if (ctld.logisticUnits ~= nil) then
			
			
		
			
		end -- end of: if (ctld.enabledFOBBuilding == true) then

	
	

	end -- end of if (ctld ~= nil) then


end



function spgg.SaveAASystemDetails()

	
	wFile:write('spgg.completeAASystems = {} \n')
	wBackupFile:write('spgg.completeAASystems = {} \n')

	for _groupName, _hawkDetails in pairs(ctld.completeAASystems) do

		if (_hawkDetails ~= nil) then


			
			wFile:write('spgg.completeAASystems["' .. _groupName .. '"] = {} \n')
			wBackupFile:write('spgg.completeAASystems["' .. _groupName .. '"] = {} \n')
			
			--spgg.completeAASystems[_groupName] = {}
			
			for i = 1, #_hawkDetails do
		
				wFile:write('table.insert(spgg.completeAASystems["'.. _groupName ..'"], {unit= "'.. _hawkDetails[i].unit ..'", name= "'.. _hawkDetails[i].name .. '", pointX= "'.. _hawkDetails[i].point.x .. '", pointY= "'.. _hawkDetails[i].point.y .. '", pointZ= "'.. _hawkDetails[i].point.z .. '", system= "'.. _hawkDetails[i].system.name ..  '" }) \n')
					
				
				--table.insert(spgg.completeAASystems[_groupName], {unit= _hawkDetails[i].unit , name= _hawkDetails[i].name, pointX= _hawkDetails[i].point.x, pointY= _hawkDetails[i].point.y, pointZ= _hawkDetails[i].point.z, system= _hawkDetails[i].system.name })
			
				wBackupFile:write('table.insert(spgg.completeAASystems["'.. _groupName ..'"], {unit= "'.. _hawkDetails[i].unit ..'", name= "'.. _hawkDetails[i].name .. '", pointX= "'.. _hawkDetails[i].point.x .. '", pointY= "'.. _hawkDetails[i].point.y .. '", pointZ= "'.. _hawkDetails[i].point.z .. '", system= "'.. _hawkDetails[i].system.name ..  '" }) \n')
			
			
			end

			

		end

	end


end









-- Loop saving

spgg.loopSaveActive = "1"

function CheckSaveStatus(ourArgument, time)
 -- Do things to check, use ourArgument (which is the scheduleFunction's second argument)
 if ourArgument == 9999 and spgg.loopSaveActive == "1" then

	-- Text saving
	--trigger.action.outText("Timed: Saving Ground Forces" , 10)
	env.info('-- SPGG - Timed: Saving Ground Forces - Start')	
	
	-- Save Ground Forces

	spgg.save()
	
	env.info('-- SPGG - Timed: Saving Ground Forces - End')
	
	-- Keep going
   return time + 3600
 else
 
 	-- Text saving
	--trigger.action.outText("Timed Last: Saving Ground Forces" , 10)
	 
	env.info('-- SPGG - Timed: Saving schedule has been canceled')
	 
	-- Save Ground Forces

	--spgg.save()
	
	--env.info('-- SPGG - Timed: Saving Ground Forces - End - Timer Schedual ended')
	
	-- That's it we're done looping
   return nil
 end
end


-- Remove content of save file and stop scheduleFunction save. Used to reset your Mission to initial state before dcs server restart.
function spgg.clearSavefile()

	spgg.loopSaveActive = "0"
	
	
	env.info('-- SPGG clear savefile : Reset file -' .. spgg.defaultDrive .. spgg.saveFilename)

	-- Reset SPGG Persistent save file
	local wFile = io.open(spgg.defaultDrive .. spgg.saveFilename, 'w')


	wFile:write('')


	wFile:close()
	wFile = nil
	
	env.info('-- SPGG clear savefile: Save file cleard!')

end






spgg.Savetime = 60 * spgg.Savetime

timer.scheduleFunction(CheckSaveStatus, 9999, timer.getTime() + spgg.Savetime)




env.info('-- SPGG - Loaded Function for Save!')
