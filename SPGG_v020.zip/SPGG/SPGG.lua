-- Simple Persistent Ground Groups (SPGG)
-- By A Glutton For Punishment (aka Kanelbolle)

env.info('-- SPGG v020 : Loading!')
spgg = spgg or {} -- do not remove


-- This parameter is used to determine where the SPGG folder is placed.
-- "lfs.writedir()" is the same as : %userprofile%\Saved Games\DCS.openbeta\ 
-- (copy the path to your Windows Explorer path line to se where this is)
--
-- Example Locations:
-- The line below is Example: C:\Users\<username>\Saved Games\DCS.OpenBeta\Missions\SPGGv020\
-- spgg.defaultDrive = lfs.writedir() .. [[Missions\SPGGv020\]]
--
-- The line below is Example: C:\MyScripts\DCS\SPGG\
-- spgg.defaultDrive = [[C:\MyScripts\DCS\SPGG\]]
--
-- The line below is : C:\Users\<username>\Saved Games\DCS.OpenBeta\Scripts\SPGG\
spgg.defaultDrive = lfs.writedir() .. [[Scripts\SPGG\]]
-- If you change this and you are loading the SPGG.lua with "DO SCRIPT" in your mission, you need to update the new path in your mission!



-- Writing the path used above to dcs.log
env.info('-- SPGG Dir: ' .. spgg.defaultDrive)


-- Settings


-- Save loop in min
spgg.Savetime = 60

-- Reuse GroupNames from save file
-- (If names exist the group will overwrite the existing unit, recommended to be false if mission is not designed for this)
spgg.ReuseGroupNames = false

-- Reuse Unit Names from save file
-- (If names exist the unit will overwrite or not spawn, recommended to be false if mission is not designed for this)
spgg.ReuseUnitNames = false

-- If "True", only the Ground groups and Sea groups that  are active in the Mission are saved. (Static objects are not inclided in the check)
spgg.saveOnlyActiveGroups = true


-- If you don't want to use "MIST" you can disable it here. (The MIST version of CTLD will not work without MIST)
-- MIST is only used for the mist.getNextGroupId() & mist.getNextUnitId() functions in the script (MIST unit Table).
-- If this option is false, DCS will controle what ID's are used.
-- Hardcoded groupid's and unitid's in other scripts might cause problems. (check that this is not the case)
-- Datalink for ground units is off if this is false (the script does not know what GroupID to assigne it to)
spgg.useMIST = true


-- Don't show Message box in DCS. Use logg file insted. (_ShowEnvinfo)
env.setErrorMessageBoxEnabled(false)

-- For debugging
spgg.showEnvinfo = false	

-- All groups names beginning with strings in this array will be excluded from saveing.
_tblExcludeGroupName = {
"AF_",
"StandAlone_",
"SA_Convoy_",
"Clone_",
"Build_",

}

-- All Static Objects with type names in this array will be included when saveing.
_tblIncludeStaticObjectType = {
"outpost",
"house2arm",
"WindTurbine"

}



spgg.saveFunctionsFilename = "SPGG_Save_v020.lua"
spgg.loadFunctionsFilename = "SPGG_load_v020.lua"

spgg.saveFilename = "SPGG_savefile.lua"








-- Load Functions
assert(loadfile(spgg.defaultDrive .. spgg.saveFunctionsFilename))()
assert(loadfile(spgg.defaultDrive .. spgg.loadFunctionsFilename))()


-- Load Saved Units data (Does not groups spawn on map)
assert(loadfile(spgg.defaultDrive .. spgg.saveFilename))()




-- Check if persistent mission start (Loading previus groups) or initial start of the mission
-- This is a flag and a parameter users can use to detirmen if SPGG loads a save file or the file is empty.
-- FLAG or parameter can example be used for the mission maker to determine if example units should only spawn if lua parameter "spgg.initalstart == true" or the flag "spgginitalstart = true"
-- Se included .miz file for example how to do this.
if (spgg.initalstart ~= nil) then

	if (spgg.initalstart == true) then
	
		trigger.action.setUserFlag("spgginitalstart" , true )
		env.info('-- SPGG : spgg.initalstart was TRUE, this is the misstions first start and not a persistent save!')
	
	else
	
		trigger.action.setUserFlag("spgginitalstart" , false )
		env.info('-- SPGG : spgg.initalstart was FALSE, this is a persisten session of the mission!')
	
	end -- of if (spgg.initalstart == true) then
	
else

	-- Parameter was nil, then this is the initial start of the mission
	spgg.initalstart = true
	trigger.action.setUserFlag("spgginitalstart" , true )
	env.info('-- SPGG : spgg.initalstart was nil, this is the misstions first start and not a persistent save!')
	
end -- of if (spgg.initalstart ~= nil) then
