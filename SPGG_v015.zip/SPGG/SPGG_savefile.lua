spgg = spgg or {}
spgg.bluegroups = spgg.bluegroups or {}
spgg.redgroups = spgg.redgroups or {}
spgg.bluestaticobj = spgg.bluestaticobj or {}
spgg.redstaticobj = spgg.redstaticobj or {}
spgg.blueseagroups = spgg.blueseagroups or {}
spgg.redseagroups = spgg.redseagroups or {}
spgg.bluegroups[1] = { ["groupname"] = "BlueAiGroundGroup5", ["units"] = {} }
spgg.bluegroups[1].units[1] = { ["type"] = "M-113", ["name"] = "BlueAi-M113-1", ["skill"] = "Excellent", ["x"] = -5559.46875, ["y"] = 242756.078125, ["heading"] = 1.5358897433863, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[2] = { ["type"] = "M-113", ["name"] = "BlueAi-M113-2", ["skill"] = "Excellent", ["x"] = -5648.1416015625, ["y"] = 242783.78125, ["heading"] = 1.5358897433863, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.redgroups[1] = { ["groupname"] = "RedAiGroundGroup6", ["units"] = {} }
spgg.redgroups[1].units[1] = { ["type"] = "BMD-1", ["name"] = "RedAiGroundUnit13", ["skill"] = "Excellent", ["x"] = -7292.9370117188, ["y"] = 293914.65625, ["heading"] = 1.5358897433863, ["playerCanDrive"] = true, ["country"]= 0, }
spgg.redgroups[1].units[2] = { ["type"] = "BMP-2", ["name"] = "RedAiGroundUnit14", ["skill"] = "Excellent", ["x"] = -7381.6103515625, ["y"] = 293942.375, ["heading"] = 1.5358897433863, ["playerCanDrive"] = true, ["country"]= 0, }
spgg.bluestaticobj[1] = { ["obj"] = {} }
spgg.bluestaticobj[1].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #7 SPGG Blue", ["x"] = -5567.6176757813, ["y"] = 242763.703125, ["heading"] = 0, ["country"]= 2, }
spgg.blueseagroups[1] = { ["groupname"] = "BlueAiSeaGroup9", ["units"] = {} }
spgg.blueseagroups[1].units[1] = { ["type"] = "PERRY", ["name"] = "BlueAiSeaUnit15", ["skill"] = "Excellent", ["x"] = -5983.5625, ["y"] = 226862.671875, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.redseagroups[1] = { ["groupname"] = "RedAiSeaGroup10", ["units"] = {} }
spgg.redseagroups[1].units[1] = { ["type"] = "PIOTR", ["name"] = "RedAiSeaUnit16", ["skill"] = "Excellent", ["x"] = -13255.989257813, ["y"] = 236415.640625, ["heading"] = -1.0995577335489, ["playerCanDrive"] = true, ["country"]= 0, }
ctld.JTAC_LIMIT_RED = 10
ctld.JTAC_LIMIT_BLUE = 10
spgg.redtroops = spgg.redtroops or {}
spgg.bluetroops = spgg.bluetroops or {}
spgg.completeAASystems = {} 
