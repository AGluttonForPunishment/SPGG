-- Simple Persistent Ground Groups (SPGG)
-- By A Glutton For Punishment (aka Kanelbolle)

env.info('-- SPGG - Loading Function for Loading Groups!')



spgg.tblPrevSamSystems = {}

local _noMistGroupCounterID = 0
local _noMistUnitCounterID = 0



-- gpUnitSize , _unitType, _unitCoord.x, _unitCoord.z, _unitHeading, _uCountry
function spgg.spawnBlueGroundGroup()


	--env.info("-- Running SpawnBlueGroundGroup!")
	
	--local _coaId = 2
	env.info('-- SPGG - Coalition BLUE : Spawning Ground Forces')
	
	if (spgg ~= nil) and (spgg.bluegroups ~= nil) then	

		for spwnGpIdx = 1, #spgg.bluegroups do

			_noMistGroupCounterID = _noMistGroupCounterID + 1 ------------------------------
			
			local _isJtacAdd = false
			local _ctldjtacGroupName = ""
			local _ctldjtacUnit = ""
			local _groupId = 0
			
			if (spgg.useMIST == true) then -----------------------------------
				_groupId = mist.getNextGroupId()
			end
			
			
			local newUnitName = ""
			local newGroupName = ""
	
			local _prevGroupName = spgg.bluegroups[spwnGpIdx].groupname or nil
			local _loadGrpName = ""
	
			if (spgg.ReuseGroupNames == true) then
				_loadGrpName = _prevGroupName
			else
			
				if (spgg.useMIST == true) then -----------------------------------
					_loadGrpName = "BlueAiGroundGroup".. _groupId
				else
					_loadGrpName = "BlueAiGroundGroupNM" .. _noMistGroupCounterID
				end -- of if (spgg.useMIST == true) then
				
			end -- of if (spgg.ReuseGroupNames == true) then
		

			local data = {

								["visible"] = false,
                                ["tasks"] = 
                                {
                                }, -- end of ["tasks"]
                                ["uncontrollable"] = false,
                                ["task"] = "Ground Nothing",
                                ["taskSelected"] = true,
                                
								["route"] =
								{
								
								},
								
                                --["groupId"] = _groupId,
                                ["hidden"] = false,
                                ["units"] = 
                                {
                                   								
							
								}, -- end of ["units"]
                            --["y"] = _uCoordZ1,
                            --["x"] = _uCoordX1,
                            ["name"] = _loadGrpName,
                            ["start_time"] = 0,
			} -- end of data

			if (spgg.useMIST == true) then --------------------------------------------
		
				data["groupId"] = _groupId
				--env.info('-- groupId with MIST: ' .. data.groupId)
		
			end


		if (spgg.showEnvinfo == true) then
			local _Msg = spgg.bluegroups[spwnGpIdx].units[1].type
			env.info("-- Loading Blue groups - Unit type : " .._Msg)
		end

					
		
					
			for spwnUnitIdx = 1, #spgg.bluegroups[spwnGpIdx].units do
                       

				_noMistUnitCounterID = _noMistUnitCounterID + 1
				local _unitId = 0
				
				if (spgg.useMIST == true) then --------------------------------------------
					_unitId 		= mist.getNextUnitId()
				end
			
				local _uType		= spgg.bluegroups[spwnGpIdx].units[spwnUnitIdx].type or ''
				local _uName		= spgg.bluegroups[spwnGpIdx].units[spwnUnitIdx].name or ''
				local _uskill		= spgg.bluegroups[spwnGpIdx].units[spwnUnitIdx].skill or ''
				local _uCoordX		= spgg.bluegroups[spwnGpIdx].units[spwnUnitIdx].x or 0
				local _uCoordY		= spgg.bluegroups[spwnGpIdx].units[spwnUnitIdx].y or 0
				local _uHdg			= spgg.bluegroups[spwnGpIdx].units[spwnUnitIdx].heading or 0
				_uCountry		= spgg.bluegroups[spwnGpIdx].units[spwnUnitIdx].country or 0
				_uPrevName		= spgg.bluegroups[spwnGpIdx].units[spwnUnitIdx].name or ''
			

				data.route = {
			
					["spans"] = 
					{
					}, -- end of ["spans"]
					["points"] = 
					{
						[1] = 
						{
							["alt"] = 59,
							["type"] = "Turning Point",
							["ETA"] = 0,
							["alt_type"] = "BARO",
							["formation_template"] = "",
							["y"] = _uCoordY,
							["x"] = _uCoordX,
							["ETA_locked"] = true,
							["speed"] = 0,
							["action"] = "Off Road",
							["task"] = 
							{
							["id"] = "ComboTask",
							["params"] = 
							{
							-- params (EPLRS) needs to know the spawning groups GroupID. Will be added only if MIST is active.
								
							}, -- end of ["params"]
						}, -- end of ["task"]
							["speed_locked"] = true,
						}, -- end of [1]
					}, -- end of ["points"]
	
				}


				if (spgg.useMIST == true) then --------------------------------------------
				
					--Since we know the groupID, we can enable EPLRS (datalink) for the group
					data.route.points[1].params = {
					
						["tasks"] = 
								{
									[1] = 
									{
										["number"] = 1,
										["auto"] = true,
										["id"] = "WrappedAction",
										["enabled"] = true,
										["params"] = 
										{
											["action"] = 
											{
												["id"] = "EPLRS",
												["params"] = 
												{
													["value"] = true,
													["groupId"] = _groupId,
												}, -- end of ["params"]
											}, -- end of ["action"]
										}, -- end of ["params"]
									}, -- end of [1]
						}, -- end of ["tasks"]
							
					
					
					} -- end of data.route.points[1].params = {
		

					--env.info('-- GroupID with MIST: ' .. data.route.points[1].params.tasks[1].params.action.params.groupId)
					--env.info('-- EPLRS groupId with MIST: ' .. data.route.points[1].params.tasks[1].params.action.id )
				
				end -- of if (spgg.useMIST == true) then


				newGroupName = _loadGrpName
				--newUnitName = "BlueAiGroundUnit".. _unitId
				
				
				
				if (spgg.ReuseUnitNames == true) then
					newUnitName = _uName
				else
				
					if (spgg.useMIST == true) then --------------------------------------------
						newUnitName = "BlueAiGroundUnit".. _unitId
					else
						newUnitName = "BlueAiGroundUnitNM".. _noMistUnitCounterID
						--env.info("-- Blue Unit Name:  " .. newUnitName)
					end -- of if (spgg.useMIST == true) then
					
				end -- of if (spgg.ReuseUnitNames == true) then


				--env.info("-- Blue Group Name:  " .. newGroupName)
				
				
				data.units[spwnUnitIdx] = {
			
					["type"] = _uType,
					--["unitId"] = _unitId,
					["skill"] = _uskill,
					["y"] = _uCoordY,
					["x"] = _uCoordX,
					["name"] = newUnitName,
					["heading"] = _uHdg,
					["playerCanDrive"] = true,
			
				}
			
			
				--data["name"] = _loadGrpName
				
				if (spgg.useMIST == true) then --------------------------------------------
					data.units[spwnUnitIdx]["unitId"] = _unitId
					--env.info('-- UnitID with MIST: ' .. data.units[spwnUnitIdx].unitId)
					
				end -- of if (spgg.useMIST == true) then
			
				

				if (ctld ~= nil) then
					-- Borrowed from CTLD (Combat Troop and Logistics Drop) for integration of JTAC in save - See https://github.com/ciribob/DCS-CTLD 
					if (ctld.isJTACUnitType ~= nil) and (ctld.JTAC_dropEnabled ~= nil) and (ctld.jtacGeneratedLaserCodes ~= nil) then
				
						if ctld.isJTACUnitType(_uType) and ctld.JTAC_dropEnabled then

							_isJtacAdd = true
							_ctldjtacGroupName = _loadGrpName
							_ctldjtacUnitName =	newUnitName
						
						end -- of if ctld.isJTACUnitType(_uType) and ctld.JTAC_dropEnabled then
			
					end -- of if (ctld.isJTACUnitType ~= nil) and (ctld.JTAC_dropEnabled ~= nil) and (ctld.jtacGeneratedLaserCodes ~= nil) then


			
					if (spgg.showEnvinfo == true) then
					
						if (spgg.useMIST == true) then --------------------------------------------
							env.info("-- Load Blue groups Unit type : " .. _uType .. " - Index : " .. spwnUnitIdx .. " - GroupID : " .. _groupId .. " - unitID : " .. _unitId)
						else
							env.info("-- Load Blue groups Unit type without MIST : " .. _uType .. " - Index : " .. spwnUnitIdx .. " - GroupID : Unknown" .. " - unitID : Unknown")
						end
						
					end -- of if (spgg.showEnvinfo == true) then



					if (spgg.completeAASystems ~= nil)  then
						
						if (spgg.showEnvinfo == true) then
							env.info("-- SPGG running spgg.completeAASystems check for :  " .. newGroupName)
						end

						for _groupName, _hawkDetails in pairs(spgg.completeAASystems) do
				
							if (_prevGroupName ~= nil) then
						

								local _grpName = _loadGrpName
								local _unitName = newUnitName
						
								local _systemName = _hawkDetails[1].system

								if (_groupName == _prevGroupName) then
							
						
									spgg.tblPrevSamSystems[_groupName] = spgg.tblPrevSamSystems[_groupName] or {}
						
									--env.info('-- spgg.completeAASystems - Grp :' .. _groupName)
						
									for i = 1, #_hawkDetails do
						
										--env.info('_hawkDetails['.. i ..'].name : ' .. _hawkDetails[i].name .. ' - ')
								
										if (_hawkDetails[i].name == _uPrevName) then
						
											local _pointX = _hawkDetails[i].pointX
											local _pointY = _hawkDetails[i].pointY
											local _pointZ = _hawkDetails[i].pointZ
						
											if (spgg.showEnvinfo == true) then
												env.info('-- spgg.completeAASystems - Found : Old group: ' .. _prevGroupName .. ' - New Group: ' .. _grpName .. ' - Old Unit Name: ' .. _hawkDetails[i].name .. ' - New Unit Name: ' ..  _unitName .. ' - System: ' .. _systemName)
											end
											
											table.insert(spgg.tblPrevSamSystems[_groupName], { ["oldSamGroupName"] = _prevGroupName, ["newSamGroupName"] = newGroupName, ["oldUnitName"] = _hawkDetails[i].name , ["newUnitName"] = _unitName ,  ["Type"] = _uType, ["pointX"] = _pointX , ["pointY"] = _pointY ,["pointZ"] = _pointZ ,["systemName"] = _systemName })
								
										end	-- end of if (_hawkDetails[i].name == _uPrevName) then

									end -- end of for i = 1, #_hawkDetails do
							
						
								end -- end of if (spgg.bluetroops[i].name == _prevGroupName) then
						
							end -- end of if (_prevGroupName ~= nil) then
					
						end -- end of for _groupName, _hawkDetails in pairs(spgg.completeAASystems) do
				
					end -- end of if (spgg.completeAASystems ~= nil)  then

				
				end -- end of if (ctld ~= nil) then
				
				
			
			end -- of for spwnUnitIdx = 1, #spgg.bluegroups[spwnGpIdx].units do
		
		
			-- Spawn group
			coalition.addGroup(_uCountry, Group.Category.GROUND, data)	

			
				if (ctld ~= nil) then
					-- Borrowed from CTLD (Combat Troop and Logistics Drop) for integration of JTAC in save - See https://github.com/ciribob/DCS-CTLD 
					if (_isJtacAdd == true) then
							
						
						local _ctldjtacUnit = Unit.getByName(_ctldjtacUnitName)
						ctld.jtacUnits[_ctldjtacGroupName] = { name = _ctldjtacUnitName, side = _ctldjtacUnit:getCoalition(), radio = _radio }

                        local _code = table.remove(ctld.jtacGeneratedLaserCodes, 1)
                        --put to the end
                        table.insert(ctld.jtacGeneratedLaserCodes, _code)

                        ctld.JTACAutoLase(_loadGrpName, _code) --(_jtacGroupName, _laserCode, _smoke, _lock, _colour)
						
						if (spgg.showEnvinfo == true) then
							env.info('-- SPGG - Coalition Blue JTAC ADDED : ' .. _loadGrpName .. ' with Laser code : ' .. _code)
						end
					end
		

					if (ctld.droppedTroopsRED ~= nil) and (spgg.bluetroops ~= nil) then
			
						for i = 1, #spgg.bluetroops do
				
							if (_prevGroupName ~= nil) then
					
								if (spgg.bluetroops[i].name == _prevGroupName) then
						
							
									if findValue(ctld.droppedTroopsRED, _loadGrpName) then
							
							
									else
							
										table.insert(ctld.droppedTroopsRED, _loadGrpName)
								
									end

							
								end -- end of if (spgg.bluetroops[i].name == _prevGroupName) then
						
							end -- end of if (_prevGroupName ~= nil) then
					
						end -- end of for i = 1, #spgg.bluetroops do
				
					end -- end of if (ctld.droppedTroopsRED ~= nil) and (spgg.bluetroops ~= nil) then
				
				end -- end of if (ctld ~= nil) then	
			








			
			--env.info('-- Spawning Group')
			
		end
									
	end		


end -- of function spgg.spawnBlueGroundGroup()






-- gpUnitSize , _unitType, _unitCoord.x, _unitCoord.z, _unitHeading, _uCountry
function spgg.spawnRedGroundGroup()


	--env.info("-- Running SpawnRedGroundGroup!")
	
	--local _coaId = 1
	env.info('-- SPGG - Coalition RED : Spawning Ground Forces')
	
	if (spgg ~= nil) and (spgg.redgroups ~= nil) then	

		for spwnGpIdx = 1, #spgg.redgroups do

			_noMistGroupCounterID = _noMistGroupCounterID + 1 ------------------------------
			
			local _isJtacAdd = false
			local _ctldjtacGroupName = ""
			local _ctldjtacUnit = ""
			local _groupId = 0
			
			if (spgg.useMIST == true) then -----------------------------------
				_groupId = mist.getNextGroupId()
			end
			
			
			local newUnitName = ""
			local newGroupName = ""
	
			local _prevGroupName = spgg.redgroups[spwnGpIdx].groupname or nil
			local _loadGrpName = ""
	
			if (spgg.ReuseGroupNames == true) then
				_loadGrpName = _prevGroupName
			else
			
				if (spgg.useMIST == true) then -----------------------------------
					_loadGrpName = "RedAiGroundGroup".. _groupId
				else
					_loadGrpName = "RedAiGroundGroupNM" .. _noMistGroupCounterID
				end -- of if (spgg.useMIST == true) then
				
			end -- of if (spgg.ReuseGroupNames == true) then
		

			local data = {

								["visible"] = false,
                                ["tasks"] = 
                                {
                                }, -- end of ["tasks"]
                                ["uncontrollable"] = false,
                                ["task"] = "Ground Nothing",
                                ["taskSelected"] = true,
                                
								["route"] =
								{
								
								},
								
                                --["groupId"] = _groupId,
                                ["hidden"] = false,
                                ["units"] = 
                                {
                                   								
							
								}, -- end of ["units"]
                            --["y"] = _uCoordZ1,
                            --["x"] = _uCoordX1,
                            ["name"] = _loadGrpName,
                            ["start_time"] = 0,
			} -- end of data

			if (spgg.useMIST == true) then --------------------------------------------
		
				data["groupId"] = _groupId
				--env.info('-- groupId with MIST: ' .. data.groupId)
		
			end


		if (spgg.showEnvinfo == true) then
			local _Msg = spgg.redgroups[spwnGpIdx].units[1].type
			env.info("-- Loading Red groups - Unit type : " .._Msg)
		end

					
		
					
			for spwnUnitIdx = 1, #spgg.redgroups[spwnGpIdx].units do
                       

				_noMistUnitCounterID = _noMistUnitCounterID + 1
				local _unitId = 0
				
				if (spgg.useMIST == true) then --------------------------------------------
					_unitId 		= mist.getNextUnitId()
				end
			
				local _uType		= spgg.redgroups[spwnGpIdx].units[spwnUnitIdx].type or ''
				local _uName		= spgg.redgroups[spwnGpIdx].units[spwnUnitIdx].name or ''
				local _uskill		= spgg.redgroups[spwnGpIdx].units[spwnUnitIdx].skill or ''
				local _uCoordX		= spgg.redgroups[spwnGpIdx].units[spwnUnitIdx].x or 0
				local _uCoordY		= spgg.redgroups[spwnGpIdx].units[spwnUnitIdx].y or 0
				local _uHdg			= spgg.redgroups[spwnGpIdx].units[spwnUnitIdx].heading or 0
				_uCountry		= spgg.redgroups[spwnGpIdx].units[spwnUnitIdx].country or 0
				_uPrevName		= spgg.redgroups[spwnGpIdx].units[spwnUnitIdx].name or ''
			

				data.route = {
			
					["spans"] = 
					{
					}, -- end of ["spans"]
					["points"] = 
					{
						[1] = 
						{
							["alt"] = 59,
							["type"] = "Turning Point",
							["ETA"] = 0,
							["alt_type"] = "BARO",
							["formation_template"] = "",
							["y"] = _uCoordY,
							["x"] = _uCoordX,
							["ETA_locked"] = true,
							["speed"] = 0,
							["action"] = "Off Road",
							["task"] = 
							{
							["id"] = "ComboTask",
							["params"] = 
							{
							-- params (EPLRS) needs to know the spawning groups GroupID. Will be added only if MIST is active.
								
							}, -- end of ["params"]
						}, -- end of ["task"]
							["speed_locked"] = true,
						}, -- end of [1]
					}, -- end of ["points"]
	
				}


				if (spgg.useMIST == true) then --------------------------------------------
				
					--Since we know the groupID, we can enable EPLRS (datalink) for the group
					data.route.points[1].params = {
					
						["tasks"] = 
								{
									[1] = 
									{
										["number"] = 1,
										["auto"] = true,
										["id"] = "WrappedAction",
										["enabled"] = true,
										["params"] = 
										{
											["action"] = 
											{
												["id"] = "EPLRS",
												["params"] = 
												{
													["value"] = true,
													["groupId"] = _groupId,
												}, -- end of ["params"]
											}, -- end of ["action"]
										}, -- end of ["params"]
									}, -- end of [1]
						}, -- end of ["tasks"]
							
					
					
					} -- end of data.route.points[1].params = {
		

					--env.info('-- GroupID with MIST: ' .. data.route.points[1].params.tasks[1].params.action.params.groupId)
					--env.info('-- EPLRS groupId with MIST: ' .. data.route.points[1].params.tasks[1].params.action.id )
				
				end -- of if (spgg.useMIST == true) then


				newGroupName = _loadGrpName
				--newUnitName = "RedAiGroundUnit".. _unitId
				
				
				
				if (spgg.ReuseUnitNames == true) then
					newUnitName = _uName
				else
				
					if (spgg.useMIST == true) then --------------------------------------------
						newUnitName = "RedAiGroundUnit".. _unitId
					else
						newUnitName = "RedAiGroundUnitNM".. _noMistUnitCounterID
						--env.info("-- Red Unit Name:  " .. newUnitName)
					end -- of if (spgg.useMIST == true) then
					
				end -- of if (spgg.ReuseUnitNames == true) then


				--env.info("-- Red Group Name:  " .. newGroupName)
				
				
				data.units[spwnUnitIdx] = {
			
					["type"] = _uType,
					--["unitId"] = _unitId,
					["skill"] = _uskill,
					["y"] = _uCoordY,
					["x"] = _uCoordX,
					["name"] = newUnitName,
					["heading"] = _uHdg,
					["playerCanDrive"] = true,
			
				}
			
			
				--data["name"] = _loadGrpName
				
				if (spgg.useMIST == true) then --------------------------------------------
					data.units[spwnUnitIdx]["unitId"] = _unitId
					--env.info('-- UnitID with MIST: ' .. data.units[spwnUnitIdx].unitId)
					
				end -- of if (spgg.useMIST == true) then
			
				

				if (ctld ~= nil) then
					-- Borrowed from CTLD (Combat Troop and Logistics Drop) for integration of JTAC in save - See https://github.com/ciribob/DCS-CTLD 
					if (ctld.isJTACUnitType ~= nil) and (ctld.JTAC_dropEnabled ~= nil) and (ctld.jtacGeneratedLaserCodes ~= nil) then
				
						if ctld.isJTACUnitType(_uType) and ctld.JTAC_dropEnabled then

							_isJtacAdd = true
							_ctldjtacGroupName = _loadGrpName
							_ctldjtacUnitName =	newUnitName
						
						end -- of if ctld.isJTACUnitType(_uType) and ctld.JTAC_dropEnabled then
			
					end -- of if (ctld.isJTACUnitType ~= nil) and (ctld.JTAC_dropEnabled ~= nil) and (ctld.jtacGeneratedLaserCodes ~= nil) then


			
					if (spgg.showEnvinfo == true) then
					
						if (spgg.useMIST == true) then --------------------------------------------
							env.info("-- Load Red groups Unit type : " .. _uType .. " - Index : " .. spwnUnitIdx .. " - GroupID : " .. _groupId .. " - unitID : " .. _unitId)
						else
							env.info("-- Load Red groups Unit type without MIST : " .. _uType .. " - Index : " .. spwnUnitIdx .. " - GroupID : Unknown" .. " - unitID : Unknown")
						end
						
					end -- of if (spgg.showEnvinfo == true) then



					if (spgg.completeAASystems ~= nil)  then
						
						if (spgg.showEnvinfo == true) then
							env.info("-- SPGG running spgg.completeAASystems check for :  " .. newGroupName)
						end

						for _groupName, _hawkDetails in pairs(spgg.completeAASystems) do
				
							if (_prevGroupName ~= nil) then
						

								local _grpName = _loadGrpName
								local _unitName = newUnitName
						
								local _systemName = _hawkDetails[1].system

								if (_groupName == _prevGroupName) then
							
						
									spgg.tblPrevSamSystems[_groupName] = spgg.tblPrevSamSystems[_groupName] or {}
						
									--env.info('-- spgg.completeAASystems - Grp :' .. _groupName)
						
									for i = 1, #_hawkDetails do
						
										--env.info('_hawkDetails['.. i ..'].name : ' .. _hawkDetails[i].name .. ' - ')
								
										if (_hawkDetails[i].name == _uPrevName) then
						
											local _pointX = _hawkDetails[i].pointX
											local _pointY = _hawkDetails[i].pointY
											local _pointZ = _hawkDetails[i].pointZ
						
											if (spgg.showEnvinfo == true) then
												env.info('-- spgg.completeAASystems - Found : Old group: ' .. _prevGroupName .. ' - New Group: ' .. _grpName .. ' - Old Unit Name: ' .. _hawkDetails[i].name .. ' - New Unit Name: ' ..  _unitName .. ' - System: ' .. _systemName)
											end
											
											table.insert(spgg.tblPrevSamSystems[_groupName], { ["oldSamGroupName"] = _prevGroupName, ["newSamGroupName"] = newGroupName, ["oldUnitName"] = _hawkDetails[i].name , ["newUnitName"] = _unitName ,  ["Type"] = _uType, ["pointX"] = _pointX , ["pointY"] = _pointY ,["pointZ"] = _pointZ ,["systemName"] = _systemName })
								
										end	-- end of if (_hawkDetails[i].name == _uPrevName) then

									end -- end of for i = 1, #_hawkDetails do
							
						
								end -- end of if (spgg.redtroops[i].name == _prevGroupName) then
						
							end -- end of if (_prevGroupName ~= nil) then
					
						end -- end of for _groupName, _hawkDetails in pairs(spgg.completeAASystems) do
				
					end -- end of if (spgg.completeAASystems ~= nil)  then

				
				end -- end of if (ctld ~= nil) then
				
				
			
			end -- of for spwnUnitIdx = 1, #spgg.redgroups[spwnGpIdx].units do
		
		
			-- Spawn group
			coalition.addGroup(_uCountry, Group.Category.GROUND, data)	

			
				if (ctld ~= nil) then
					-- Borrowed from CTLD (Combat Troop and Logistics Drop) for integration of JTAC in save - See https://github.com/ciribob/DCS-CTLD 
					if (_isJtacAdd == true) then
							
						
						local _ctldjtacUnit = Unit.getByName(_ctldjtacUnitName)
						ctld.jtacUnits[_ctldjtacGroupName] = { name = _ctldjtacUnitName, side = _ctldjtacUnit:getCoalition(), radio = _radio }

                        local _code = table.remove(ctld.jtacGeneratedLaserCodes, 1)
                        --put to the end
                        table.insert(ctld.jtacGeneratedLaserCodes, _code)

                        ctld.JTACAutoLase(_loadGrpName, _code) --(_jtacGroupName, _laserCode, _smoke, _lock, _colour)
						
						if (spgg.showEnvinfo == true) then
							env.info('-- SPGG - Coalition Red JTAC ADDED : ' .. _loadGrpName .. ' with Laser code : ' .. _code)
						end
					end
		

					if (ctld.droppedTroopsRED ~= nil) and (spgg.redtroops ~= nil) then
			
						for i = 1, #spgg.redtroops do
				
							if (_prevGroupName ~= nil) then
					
								if (spgg.redtroops[i].name == _prevGroupName) then
						
							
									if findValue(ctld.droppedTroopsRED, _loadGrpName) then
							
							
									else
							
										table.insert(ctld.droppedTroopsRED, _loadGrpName)
								
									end

							
								end -- end of if (spgg.redtroops[i].name == _prevGroupName) then
						
							end -- end of if (_prevGroupName ~= nil) then
					
						end -- end of for i = 1, #spgg.redtroops do
				
					end -- end of if (ctld.droppedTroopsRED ~= nil) and (spgg.redtroops ~= nil) then
				
				end -- end of if (ctld ~= nil) then	
			








			
			--env.info('-- Spawning Group')
			
		end
									
	end		


end -- of function spgg.spawnRedGroundGroup()











function spgg.spawnBlueStaticObject()


	--local _coaId = 2
	
	
		
	env.info('-- SPGG - Coalition BLUE : Spawning Static Objects')
			
		

	if (spgg ~= nil) and (spgg.bluestaticobj ~= nil) then

	

		for spwnSoIdx = 1, #spgg.bluestaticobj do


			local _unitId = 0
			local _groupId = 0
			
			_noMistGroupCounterID = _noMistGroupCounterID + 1 
			_noMistUnitCounterID = _noMistUnitCounterID + 1 ------------------------------
			
			
			if (spgg.useMIST == true) then -----------------------------------
				_unitId = mist.getNextGroupId()
				_groupId = mist.getNextGroupId()
			end
			

			
			local _soType		= spgg.bluestaticobj[spwnSoIdx].obj[1].type or ''
			
			local _soCategory		= spgg.bluestaticobj[spwnSoIdx].obj[1].category or 1
			
			local _soPrevName	= spgg.bluestaticobj[spwnSoIdx].obj[1].name or ''
			local _soCoordX		= spgg.bluestaticobj[spwnSoIdx].obj[1].x or 0
			local _soCoordY		= spgg.bluestaticobj[spwnSoIdx].obj[1].y or 0
			local _soHdg		= spgg.bluestaticobj[spwnSoIdx].obj[1].heading or 0
			local _uCountry		= spgg.bluestaticobj[spwnSoIdx].obj[1].country or 2
	
	
	
			local _data = {
				
				["category"] = _soCategory,
				["type"] = _soType,
				--["unitId"] = _unitId,
				["y"] = _soCoordY,
				["x"] = _soCoordX,
				["canCargo"] = false,
				["heading"] = _soHdg,
				--["groupId"] = _groupId,
				
			}

			if (spgg.useMIST == true) then --------------------------------------------
		
				_data["groupId"] = _groupId
				_data["unitId"] = _unitId
				--_data.units[1]["unitId"] = _unitId
				
		
			end

			if (spgg.ReuseUnitNames == true) then
					_soNewName = _soPrevName
			else
				
					if (spgg.useMIST == true) then --------------------------------------------
						_soNewName = "Static Object #" .._unitId.. " Blue"
					else

						_soNewName = "Static Object NM #" .. _noMistUnitCounterID .. " Blue"
						
					end -- of if (spgg.useMIST == true) then
					
			end -- of if (spgg.ReuseUnitNames == true) then

		
			
			_data["country"] = _uCountry
			_data["name"] = _soNewName
			
			--_soNewName = "Static Object #" .._unitId.. " Blue"
			--_data.units[1]["name"] = _soNewName .. '-1-1'
			--_data.units[1]["type"] = _soType
			--_data.units[1]["heading"] = _soHdg
			--_data.units[1]["category"] = _soCategory
			
			
			coalition.addStaticObject(_uCountry, _data)	
			--mist.dynAddStatic(_data)
		
			if (spgg.showEnvinfo == true) then
				env.info("-- Load Blue Static Object type : " .. _soType .. " - Category: " .. _soCategory .. " - Index : " .. spwnSoIdx .. " - GroupID : " .. _groupId .. " - unitID : " .. _unitId .. " - New Name : " .. _soNewName)
			end
		
		
			if (ctld ~= nil) then
			
				-- Check if CTLD has base building Enabled
				if (ctld.enabledFOBBuilding ~= nil) then
		
					if (ctld.enabledFOBBuilding == true) then
		
						--table.insert(ctld.logisticUnits, _soNewName)



						if (ctld.logisticUnits ~= nil) and (spgg.logisticUnits ~= nil) then
			
							for i = 1, #spgg.logisticUnits do
				
								if (_soPrevName ~= nil) then
					
									if (spgg.logisticUnits[i].name == _soPrevName) then
						
							
										if findValue(ctld.logisticUnits, _soNewName) then
							
										else
											
											if (spgg.showEnvinfo == true) then
												env.info("-- Load Blue Static Object type in to ctld.logisticUnits : " .. _soType .. " - Category: " .. _soCategory .. " - Index : " .. spwnSoIdx .. " - GroupID : " .. _groupId .. " - unitID : " .. _unitId)
											end
											table.insert(ctld.logisticUnits, _soNewName)
								
										end -- end of: if findValue(ctld.logisticUnits, _soNewName) then

							
									end -- end of: if (spgg.logisticUnits[i].name == _soPrevName) then
						
								end -- end of: if (_soPrevName ~= nil) then
					
							end -- end of: for i = 1, #spgg.logisticUnits do
				
						end -- end of: if (ctld.logisticUnits ~= nil) and (spgg.logisticUnits ~= nil) then

						
						
						
						
						if (ctld.troopPickupAtFOB == true) then
							--table.insert(ctld.builtFOBS, _soNewName)
							
							
							
							if (ctld.builtFOBS ~= nil) and (spgg.builtFOBS ~= nil) then
			
								for i = 1, #spgg.builtFOBS do
				
									if (_soPrevName ~= nil) then
					
										if (spgg.builtFOBS[i].name == _soPrevName) then
						
							
											if findValue(ctld.builtFOBS, _soNewName) then
							
											else
							
												if (spgg.showEnvinfo == true) then
													env.info("-- Load Blue Static Object type in to ctld.builtFOBS : " .. _soType .. " - Category: " .. _soCategory .. " - Index : " .. spwnSoIdx .. " - GroupID : " .. _groupId .. " - unitID : " .. _unitId)
												end
												table.insert(ctld.builtFOBS, _soNewName)
								
											end -- end of: if findValue(ctld.builtFOBS, _soNewName) then

							
										end -- end of: if (spgg.builtFOBS[i].name == _soPrevName) then
						
									end -- end of: if (_soPrevName ~= nil) then
					
								end -- end of: for i = 1, #spgg.builtFOBS do
				
							end -- end of: if (ctld.builtFOBS ~= nil) and (spgg.builtFOBS ~= nil) then
							
							
							
							
							
						end -- end of: if (ctld.troopPickupAtFOB == true) then
		
					end -- end of: if (ctld.enabledFOBBuilding == true) then
		
				end -- end of: if (ctld.enabledFOBBuilding ~= nil) then
				
				
				
			end -- end of if (ctld ~= nil) then
			
			
	
		end  -- end of for spwnSoIdx = 1, #spgg.bluestaticobj do

	end -- of if (spgg ~= nil) and (spgg.bluestaticobj ~= nil) then
	
end -- of function spgg.spawnBlueStaticObject()







function spgg.spawnRedStaticObject()


	--local _coaId = 2
	
	
		
	env.info('-- SPGG - Coalition RED : Spawning Static Objects')
			
		

	if (spgg ~= nil) and (spgg.redstaticobj ~= nil) then

	

		for spwnSoIdx = 1, #spgg.redstaticobj do


			local _unitId = 0
			local _groupId = 0
			
			_noMistGroupCounterID = _noMistGroupCounterID + 1 
			_noMistUnitCounterID = _noMistUnitCounterID + 1 ------------------------------
			
			
			if (spgg.useMIST == true) then -----------------------------------
				_unitId = mist.getNextGroupId()
				_groupId = mist.getNextGroupId()
			end
			

			
			local _soType		= spgg.redstaticobj[spwnSoIdx].obj[1].type or ''
			
			local _soCategory		= spgg.redstaticobj[spwnSoIdx].obj[1].category or 1
			
			local _soPrevName	= spgg.redstaticobj[spwnSoIdx].obj[1].name or ''
			local _soCoordX		= spgg.redstaticobj[spwnSoIdx].obj[1].x or 0
			local _soCoordY		= spgg.redstaticobj[spwnSoIdx].obj[1].y or 0
			local _soHdg		= spgg.redstaticobj[spwnSoIdx].obj[1].heading or 0
			local _uCountry		= spgg.redstaticobj[spwnSoIdx].obj[1].country or 2
	
	
	
			local _data = {
				
				["category"] = _soCategory,
				["type"] = _soType,
				--["unitId"] = _unitId,
				["y"] = _soCoordY,
				["x"] = _soCoordX,
				["canCargo"] = false,
				["heading"] = _soHdg,
				--["groupId"] = _groupId,
				
			}

			if (spgg.useMIST == true) then --------------------------------------------
		
				_data["groupId"] = _groupId
				_data["unitId"] = _unitId
				--_data.units[1]["unitId"] = _unitId
				
		
			end

			if (spgg.ReuseUnitNames == true) then
					_soNewName = _soPrevName
			else
				
					if (spgg.useMIST == true) then --------------------------------------------
						_soNewName = "Static Object #" .._unitId.. " Red"
					else

						_soNewName = "Static Object NM #" .. _noMistUnitCounterID .. " Red"
						
					end -- of if (spgg.useMIST == true) then
					
			end -- of if (spgg.ReuseUnitNames == true) then

		
			
			_data["country"] = _uCountry
			_data["name"] = _soNewName
			
			--_soNewName = "Static Object #" .._unitId.. " Red"
			--_data.units[1]["name"] = _soNewName .. '-1-1'
			--_data.units[1]["type"] = _soType
			--_data.units[1]["heading"] = _soHdg
			--_data.units[1]["category"] = _soCategory
			
			
			coalition.addStaticObject(_uCountry, _data)	
			--mist.dynAddStatic(_data)
		
			if (spgg.showEnvinfo == true) then
				env.info("-- Load Red Static Object type : " .. _soType .. " - Category: " .. _soCategory .. " - Index : " .. spwnSoIdx .. " - GroupID : " .. _groupId .. " - unitID : " .. _unitId .. " - New Name : " .. _soNewName)
			end
		
		
			if (ctld ~= nil) then
			
				-- Check if CTLD has base building Enabled
				if (ctld.enabledFOBBuilding ~= nil) then
		
					if (ctld.enabledFOBBuilding == true) then
		
						--table.insert(ctld.logisticUnits, _soNewName)



						if (ctld.logisticUnits ~= nil) and (spgg.logisticUnits ~= nil) then
			
							for i = 1, #spgg.logisticUnits do
				
								if (_soPrevName ~= nil) then
					
									if (spgg.logisticUnits[i].name == _soPrevName) then
						
							
										if findValue(ctld.logisticUnits, _soNewName) then
							
										else
											
											if (spgg.showEnvinfo == true) then
												env.info("-- Load Red Static Object type in to ctld.logisticUnits : " .. _soType .. " - Category: " .. _soCategory .. " - Index : " .. spwnSoIdx .. " - GroupID : " .. _groupId .. " - unitID : " .. _unitId)
											end
											table.insert(ctld.logisticUnits, _soNewName)
								
										end -- end of: if findValue(ctld.logisticUnits, _soNewName) then

							
									end -- end of: if (spgg.logisticUnits[i].name == _soPrevName) then
						
								end -- end of: if (_soPrevName ~= nil) then
					
							end -- end of: for i = 1, #spgg.logisticUnits do
				
						end -- end of: if (ctld.logisticUnits ~= nil) and (spgg.logisticUnits ~= nil) then

						
						
						
						
						if (ctld.troopPickupAtFOB == true) then
							--table.insert(ctld.builtFOBS, _soNewName)
							
							
							
							if (ctld.builtFOBS ~= nil) and (spgg.builtFOBS ~= nil) then
			
								for i = 1, #spgg.builtFOBS do
				
									if (_soPrevName ~= nil) then
					
										if (spgg.builtFOBS[i].name == _soPrevName) then
						
							
											if findValue(ctld.builtFOBS, _soNewName) then
							
											else
							
												if (spgg.showEnvinfo == true) then
													env.info("-- Load Red Static Object type in to ctld.builtFOBS : " .. _soType .. " - Category: " .. _soCategory .. " - Index : " .. spwnSoIdx .. " - GroupID : " .. _groupId .. " - unitID : " .. _unitId)
												end
												table.insert(ctld.builtFOBS, _soNewName)
								
											end -- end of: if findValue(ctld.builtFOBS, _soNewName) then

							
										end -- end of: if (spgg.builtFOBS[i].name == _soPrevName) then
						
									end -- end of: if (_soPrevName ~= nil) then
					
								end -- end of: for i = 1, #spgg.builtFOBS do
				
							end -- end of: if (ctld.builtFOBS ~= nil) and (spgg.builtFOBS ~= nil) then
							
							
							
							
							
						end -- end of: if (ctld.troopPickupAtFOB == true) then
		
					end -- end of: if (ctld.enabledFOBBuilding == true) then
		
				end -- end of: if (ctld.enabledFOBBuilding ~= nil) then
				
				
				
			end -- end of if (ctld ~= nil) then
			
			
	
		end  -- end of for spwnSoIdx = 1, #spgg.redstaticobj do

	end -- end of if (spgg ~= nil) and (spgg.redstaticobj ~= nil) then
	
end -- of function spgg.spawnRedStaticObject()















-- gpUnitSize , _unitType, _unitCoord.x, _unitCoord.z, _unitHeading, _uCountry
function spgg.spawnBlueSeaGroup()


	--env.info("-- Running SpawnBlueGroundGroup!")
	
	--local _coaId = 2
	env.info('-- SPGG - Coalition BLUE : Spawning Sea Forces')
	


	
if (spgg ~= nil) and (spgg.blueseagroups ~= nil) then	

	for spwnGpIdx = 1, #spgg.blueseagroups do


		local _unitId = 0
		local _groupId = 0
			
		_noMistGroupCounterID = _noMistGroupCounterID + 1 

		if (spgg.useMIST == true) then -----------------------------------
			_groupId = mist.getNextGroupId()
		end

		local _isJtacAdd = false
		local _ctldjtacGroupName = ""
		local _ctldjtacUnit = ""

		
		local _prevGroupName = spgg.blueseagroups[spwnGpIdx].groupname or nil
		local _loadGrpName = ""
	
	
		if (spgg.ReuseUnitNames == true) then
					_loadGrpName = _prevGroupName
				else
				
					if (spgg.useMIST == true) then --------------------------------------------
						_loadGrpName = "BlueAiSeaGroup".. _groupId
					else
						_loadGrpName = "BlueAiSeaGroupNM".. _noMistGroupCounterID
					end -- of if (spgg.useMIST == true) then
					
		end -- of if (spgg.ReuseUnitNames == true) then
	

		local data = {

								["visible"] = false,
                                ["tasks"] = 
                                {
                                }, -- end of ["tasks"]
                                ["uncontrollable"] = false,
                                 
								["route"] =
								{
								
								},
								
                                --["groupId"] = _groupId,
                                ["hidden"] = false,
                                ["units"] = 
                                {
                                   								
							
								}, -- end of ["units"]
                            --["y"] = _uCoordZ1,
                            --["x"] = _uCoordX1,
                            ["name"] = _loadGrpName,
                            --["start_time"] = 0,
		} -- end of data

	
		
					
		for spwnUnitIdx = 1, #spgg.blueseagroups[spwnGpIdx].units do
                       

			_noMistUnitCounterID = _noMistUnitCounterID + 1 ------------------------------

			if (spgg.useMIST == true) then -----------------------------------
				_unitId = mist.getNextGroupId()
			end
			
			local _uType		= spgg.blueseagroups[spwnGpIdx].units[spwnUnitIdx].type or ''
			local _uName		= spgg.blueseagroups[spwnGpIdx].units[spwnUnitIdx].name or ''
			local _uskill		= spgg.blueseagroups[spwnGpIdx].units[spwnUnitIdx].skill or ''
			local _uCoordX		= spgg.blueseagroups[spwnGpIdx].units[spwnUnitIdx].x or 0
			local _uCoordY		= spgg.blueseagroups[spwnGpIdx].units[spwnUnitIdx].y or 0
			local _uHdg			= spgg.blueseagroups[spwnGpIdx].units[spwnUnitIdx].heading or 0
			_uCountry			= spgg.blueseagroups[spwnGpIdx].units[spwnUnitIdx].country or 2
			
			
			data.route = {
			
				["spans"] = 
				{
				}, -- end of ["spans"]
				["points"] = 
				{
					[1] = 
					{
						["alt"] = 59,
						["type"] = "Turning Point",
						["ETA"] = 0,
						["alt_type"] = "BARO",
						["formation_template"] = "",
						["y"] = _uCoordY,
						["x"] = _uCoordX,
						["ETA_locked"] = true,
						["speed"] = 0,
						["action"] = "Turning Point",
						["task"] = 
                        {
                            ["id"] = "ComboTask",
                            ["params"] = 
                            {
                                ["tasks"] = 
                                    {
                                    }, -- end of ["tasks"]
                            }, -- end of ["params"]
                        }, -- end of ["task"]
						["speed_locked"] = true,
					}, -- end of [1]
				}, -- end of ["points"]
	
			}


			if (spgg.ReuseUnitNames == true) then
					newUnitName = _uName
				else
				
					if (spgg.useMIST == true) then --------------------------------------------
						newUnitName = "BlueAiSeaUnit".. _unitId
					else
						newUnitName = "BlueAiSeaUnitNM".. _noMistUnitCounterID
						--env.info("-- Red Unit Name:  " .. newUnitName)
					end -- of if (spgg.useMIST == true) then
					
			end -- of if (spgg.ReuseUnitNames == true) then


			data.units[spwnUnitIdx] = {
			
					["type"] = _uType,
					--["unitId"] = _unitId,
					["skill"] = _uskill,
					["y"] = _uCoordY,
					["x"] = _uCoordX,
					["name"] = newUnitName,
					["heading"] = _uHdg,
			
			}
			
			
			data["name"] = _loadGrpName

			if (spgg.useMIST == true) then --------------------------------------------
				data.units[spwnUnitIdx]["unitId"] = _unitId
			end -- of if (spgg.useMIST == true) then



			
			if (spgg.showEnvinfo == true) then
				env.info("-- Load Blue Sea unit type : " .. _uType .. " - Index : " .. spwnGpIdx .. " - GroupID : " .. _groupId .. " - unitID : " .. _unitId)
			end
					   
		
				
		end -- end of for spwnUnitIdx = 1, #spgg.blueseagroups[spwnGpIdx].units do
		
		
			coalition.addGroup(_uCountry, Group.Category.SHIP, data)	

			
					
			
			
		--env.info('-- Spawning Group')
			
	end
									
				
				


	end -- end of if (spgg ~= nil) and (spgg.blueseagroups ~= nil) then	

end -- of function spgg.spawnBlueSeaGroup()







-- gpUnitSize , _unitType, _unitCoord.x, _unitCoord.z, _unitHeading, _uCountry
function spgg.spawnRedSeaGroup()


	--env.info("-- Running SpawnRedGroundGroup!")
	
	--local _coaId = 2
	env.info('-- SPGG - Coalition RED : Spawning Sea Forces')
	


	
if (spgg ~= nil) and (spgg.redseagroups ~= nil) then	

	for spwnGpIdx = 1, #spgg.redseagroups do


		local _unitId = 0
		local _groupId = 0
			
		_noMistGroupCounterID = _noMistGroupCounterID + 1 

		if (spgg.useMIST == true) then -----------------------------------
			_groupId = mist.getNextGroupId()
		end

		local _isJtacAdd = false
		local _ctldjtacGroupName = ""
		local _ctldjtacUnit = ""

		
		local _prevGroupName = spgg.redseagroups[spwnGpIdx].groupname or nil
		local _loadGrpName = ""
	
	
		if (spgg.ReuseUnitNames == true) then
					_loadGrpName = _prevGroupName
				else
				
					if (spgg.useMIST == true) then --------------------------------------------
						_loadGrpName = "RedAiSeaGroup".. _groupId
					else
						_loadGrpName = "RedAiSeaGroupNM".. _noMistGroupCounterID
					end -- of if (spgg.useMIST == true) then
					
		end -- of if (spgg.ReuseUnitNames == true) then
	

		local data = {

								["visible"] = false,
                                ["tasks"] = 
                                {
                                }, -- end of ["tasks"]
                                ["uncontrollable"] = false,
                                 
								["route"] =
								{
								
								},
								
                                --["groupId"] = _groupId,
                                ["hidden"] = false,
                                ["units"] = 
                                {
                                   								
							
								}, -- end of ["units"]
                            --["y"] = _uCoordZ1,
                            --["x"] = _uCoordX1,
                            ["name"] = _loadGrpName,
                            --["start_time"] = 0,
		} -- end of data

	
		
					
		for spwnUnitIdx = 1, #spgg.redseagroups[spwnGpIdx].units do
                       

			_noMistUnitCounterID = _noMistUnitCounterID + 1 ------------------------------

			if (spgg.useMIST == true) then -----------------------------------
				_unitId = mist.getNextGroupId()
			end
			
			local _uType		= spgg.redseagroups[spwnGpIdx].units[spwnUnitIdx].type or ''
			local _uName		= spgg.redseagroups[spwnGpIdx].units[spwnUnitIdx].name or ''
			local _uskill		= spgg.redseagroups[spwnGpIdx].units[spwnUnitIdx].skill or ''
			local _uCoordX		= spgg.redseagroups[spwnGpIdx].units[spwnUnitIdx].x or 0
			local _uCoordY		= spgg.redseagroups[spwnGpIdx].units[spwnUnitIdx].y or 0
			local _uHdg			= spgg.redseagroups[spwnGpIdx].units[spwnUnitIdx].heading or 0
			_uCountry			= spgg.redseagroups[spwnGpIdx].units[spwnUnitIdx].country or 2
			
			
			data.route = {
			
				["spans"] = 
				{
				}, -- end of ["spans"]
				["points"] = 
				{
					[1] = 
					{
						["alt"] = 59,
						["type"] = "Turning Point",
						["ETA"] = 0,
						["alt_type"] = "BARO",
						["formation_template"] = "",
						["y"] = _uCoordY,
						["x"] = _uCoordX,
						["ETA_locked"] = true,
						["speed"] = 0,
						["action"] = "Turning Point",
						["task"] = 
                        {
                            ["id"] = "ComboTask",
                            ["params"] = 
                            {
                                ["tasks"] = 
                                    {
                                    }, -- end of ["tasks"]
                            }, -- end of ["params"]
                        }, -- end of ["task"]
						["speed_locked"] = true,
					}, -- end of [1]
				}, -- end of ["points"]
	
			}


			if (spgg.ReuseUnitNames == true) then
					newUnitName = _uName
				else
				
					if (spgg.useMIST == true) then --------------------------------------------
						newUnitName = "RedAiSeaUnit".. _unitId
					else
						newUnitName = "RedAiSeaUnitNM".. _noMistUnitCounterID
						--env.info("-- Red Unit Name:  " .. newUnitName)
					end -- of if (spgg.useMIST == true) then
					
			end -- of if (spgg.ReuseUnitNames == true) then


			data.units[spwnUnitIdx] = {
			
					["type"] = _uType,
					--["unitId"] = _unitId,
					["skill"] = _uskill,
					["y"] = _uCoordY,
					["x"] = _uCoordX,
					["name"] = newUnitName,
					["heading"] = _uHdg,
			
			}
			
			
			data["name"] = _loadGrpName

			if (spgg.useMIST == true) then --------------------------------------------
				data.units[spwnUnitIdx]["unitId"] = _unitId
			end -- of if (spgg.useMIST == true) then



			
			if (spgg.showEnvinfo == true) then
				env.info("-- Load Red Sea unit type : " .. _uType .. " - Index : " .. spwnGpIdx .. " - GroupID : " .. _groupId .. " - unitID : " .. _unitId)
			end
					   
		
				
		end -- end of for spwnUnitIdx = 1, #spgg.redseagroups[spwnGpIdx].units do
		
		
			coalition.addGroup(_uCountry, Group.Category.SHIP, data)	

			
					
			
			
		--env.info('-- Spawning Group')
			
	end
									
				
				


	end -- end of if (spgg ~= nil) and (spgg.redseagroups ~= nil) then	

end -- of function spgg.spawnRedSeaGroup()










function spgg.findAndAddSamSystems()

env.info('-- SPGG : Running spgg.findAndAddSamSystems')

-- spgg.tblPrevSamSystems[i] = { ["oldSamGroupName"] = _prevGroupName, ["newSamGroupName"] = _grpName, ["systemName"] = _systemName }

	if (spgg.tblPrevSamSystems ~= nil)  then
			
				
				
				
				for _groupName, _hawkDetails in pairs(spgg.tblPrevSamSystems) do
				

					for i = 1, #_hawkDetails do
				
						if (_groupName ~= nil) and (_hawkDetails ~= nil) then
						
						local _oldGrpName = _hawkDetails[i].oldSamGroupName
						local _newGrpName = _hawkDetails[i].newSamGroupName
						
							
							if findValue(ctld.completeAASystems, _newGrpName) then
							
								env.info('-- ctld.completeAASystems - Found : '.. _newGrpName)
							
							else
								
								env.info('-- ctld.completeAASystems - Did not find, adding to ctld.completeAASystems : '.. _newGrpName)

								ctld.completeAASystems[_newGrpName] = spgg.LoadAASystemDetails(_oldGrpName)
									
								
							end
								
							
						
						
						
						end -- end of if (_prevGroupName ~= nil) then
					
					end
					
					
				end -- end of for i = 1, #spgg.bluetroops do
				
				
				
				
				
			end -- end of if (ctld.droppedTroopsBLUE ~= nil) and (spgg.bluetroops ~= nil) then





end




function spgg.LoadAASystemDetails(_oldSAMGrpName)

	local _SAMDetails = {}

	if (spgg.tblPrevSamSystems ~= nil)  then
			
				for _groupName, _hawkDetails in pairs(spgg.tblPrevSamSystems) do
				
					if (_groupName ~= nil) then
			
						for i = 1, #_hawkDetails do
		

						
						
							if (_oldSAMGrpName == _groupName) then
								

								local _type = _hawkDetails[i].Type
								local _name = _hawkDetails[i].newUnitName
								local _system = _hawkDetails[i].systemName
						

								
								local _point = {

									["x"] = _hawkDetails[i].pointX,
									["y"] = _hawkDetails[i].pointY,
									["z"] = _hawkDetails[i].pointZ,
								}
								
								if (spgg.showEnvinfo == true) then
									env.info('-- SPGG tblPrevSamSystems Adding Hawk name : '.. _hawkDetails[i].newUnitName)
								end
								--table.insert(_SAMDetails, { point = _point, unit = _type, name = _name, system = _system})
								
								--table.insert(_SAMDetails, { point = _point, unit = _type, name = _name, system = ctld.AASystemTemplate.name[_system]})
								
								for i = 1, #ctld.AASystemTemplate do
							
									if ctld.AASystemTemplate[i].name == _system then
									
										if (spgg.showEnvinfo == true) then
											env.info('-- CTLD completeAASystems Temp TEST : '.. ctld.AASystemTemplate[i].name)
										end
										--table.insert(_SAMTestTable, { tname = _groupName, system = ctld.AASystemTemplate.name[_hDetails]})
										--table.insert(_SAMTestTable, { tname = _groupName, system = ctld.AASystemTemplate[i] })
										table.insert(_SAMDetails, { point = _point, unit = _type, name = _name, system = ctld.AASystemTemplate[i] })
									end
								end 
								
								
						
							end
							
							
							
						end
				
					end

						
				end
					
	end
	
	
	return _SAMDetails
	
end









env.info('-- SPGG - Loaded Function for Loading Groups!')





