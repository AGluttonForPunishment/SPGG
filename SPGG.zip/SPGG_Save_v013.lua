-- Simple Persistent Ground Groups (SPGG)
env.info('-- SPGG - Loading Function for Save!')





function findIfValueInArray(whichArray, itemName)
		for currentIndex = 1, #whichArray do
			--if whichArray[currentIndex] == itemName then
			if string.match(itemName, '^' .. whichArray[currentIndex] .. '.*$') then
				
						--env.info('-- Found in '.. whichArray[currentIndex] ..' : ' .. itemName)
				
								--Sends true back if value exist
				return true
			end
		end
end

function findValue(whichArray, itemName)
		for currentIndex = 1, #whichArray do
			if whichArray[currentIndex] == itemName then
								--Sends true back if value exist
				return true
			end
		end
end




function save_time(time)
  local days = math.floor(time/86400)
  local hours = math.floor(math.mod(time, 86400)/3600)
  local minutes = math.floor(math.mod(time,3600)/60)
  local seconds = math.floor(math.mod(time,60))
  return string.format("%d_%02d_%02d_%02d",days,hours,minutes,seconds)
end










function SPGGSave()

	env.info('-- ')
	env.info('-- SPGG - Running SPGGSave()')

	_groupBlueCount = 0
	_groupRedCount = 0
	_soBlueCount = 0
	_soRedCount = 0


	wFile = io.open(_defaultDriveSPGG .. _PersistentGroupsSaveFilename, 'w')
	


	wFile:write('spgg = spgg or {}' .. '\n')
	
	wFile:write('spgg.bluegroups = spgg.bluegroups or {}' .. '\n')
	wFile:write('spgg.redgroups = spgg.redgroups or {}' .. '\n')
	
	
	wFile:write('spgg.bluestaticobj = spgg.bluestaticobj or {}' .. '\n')

	
	wFile:write('spgg.redstaticobj = spgg.redstaticobj or {}' .. '\n')
	
	
	--Backup save file
	local _timesave = timer.getTime()
	local _dhmsTimeleft = save_time(_timesave)
	wBackupFile = io.open(_defaultDriveSPGG .. "Backup-Saves\\" .. _PersistentGroupsSaveFilename .. "_inGameTime_" .. _dhmsTimeleft .. '.lua', 'w')
	
	wBackupFile:write('spgg = spgg or {}' .. '\n')
	wBackupFile:write('spgg.bluegroups = spgg.bluegroups or {}' .. '\n')
	wBackupFile:write('spgg.redgroups = spgg.redgroups or {}' .. '\n')
	wBackupFile:write('spgg.bluestaticobj = spgg.bluestaticobj or {}' .. '\n')
	wBackupFile:write('spgg.redstaticobj = spgg.redstaticobj or {}' .. '\n')

	

	-----------------------------------
	-- Get Blue Coalition Forces	-------------------
	-----------------------------------
	for i, gp in pairs(coalition.getGroups(2, 2)) do

		local _GpName = Group.getName(gp)
		
		if _GpName ~= nil then
		
				if (Group.getByName(_GpName) and Group.getByName(_GpName):getSize() > 0) and (Group.isExist(gp) == true) then
		
					
					if findIfValueInArray(_tblExcludeGroupName, _GpName) then
					
						-- Do nothing if it is excluded!
						
						if (_ShowEnvinfo == true) then
							env.info('-- SPGG - Excluded Blue Group: ' .. _GpName)
						end
						
					else
						
						local _gpUnitSize = Group.getByName(_GpName):getSize()
						
						getGroupAndSave(2, _GpName, _gpUnitSize)
						
					
					end -- if (findValue(_tblExcludeGroupName, _GpName) ~= nil) then
		
		
				end
		
		
		end -- if _GpName =~ nil then
		
		
	end -- for i, gp in pairs(coalition.getGroups(2,2)) do







	-----------------------------------
	-- Get Red Coalition Forces	-------------------
	-----------------------------------
	for i, gp in pairs(coalition.getGroups(1, 2)) do

		local _GpName = Group.getName(gp)
		
		if _GpName ~= nil then
		
				if (Group.getByName(_GpName) and Group.getByName(_GpName):getSize() > 0) and (Group.isExist(gp) == true) then
		
		
		
					if findIfValueInArray(_tblExcludeGroupName, _GpName) then
					
						-- Do nothing if it is excluded!
						if (_ShowEnvinfo == true) then
							env.info('-- SPGG - Excluded Red Group: ' .. _GpName)
						end
						
					else
						
						local _gpUnitSize = Group.getByName(_GpName):getSize()
						
						getGroupAndSave(1, _GpName, _gpUnitSize)
						
					
					end -- if (findValue(_tblExcludeGroupName, _GpName) ~= nil) then
		
		
				end
		
		
		end -- if _GpName =~ nil then
		
		
	end -- for i, gp in pairs(coalition.getGroups(2,2)) do








	-----------------------------------
	-- Static Blue Objects	-------------------
	-----------------------------------

	

	for i, so in pairs(coalition.getStaticObjects(2)) do


	local _SoName = StaticObject.getName(so)
	local _SoType = so:getTypeName()
 
 
 
		
		if (StaticObject.getByName(_SoName)) and (StaticObject.isExist(so)) then
 
			--trigger.action.outText("Exsist : " .._SoName , 10)
		
			if ( findValue(_tblIncludeStaticObjectType, _SoType)) then
		
				if (_ShowEnvinfo == true) then
					env.info('-- SPGG - Found Blue Static Object : '.. _SoName.. ' - Type : ' .. _SoType)
				end
				
		
				if ( findIfValueInArray(_tblExcludeGroupName, _SoName)) then
				
					if (_ShowEnvinfo == true) then
						env.info('-- SPGG - Excluded Blue Static Object - On Excluded Name List: ' .. _SoName.. ' - Type : ' .. _SoType)
					end
					
				else --if (_SoName == string.match(_SoName, '^Deployed FOB.*$')) then
				
					if (_ShowEnvinfo == true) then
						env.info('-- SPGG - Saving Blue Static Object: '.. _SoName .. ' - Type : ' .. _SoType)
					end
					
						
					getObjectAndSave(2, _SoName)
					
					
					
				end
			end
		
		
		
		end

	end -- for i, so in pairs(coalition.getStaticObjects(1)) do



	-----------------------------------
	-- Static Red Objects	-------------------
	-----------------------------------


	
	
	for i, so in pairs(coalition.getStaticObjects(1)) do


	local _SoName = StaticObject.getName(so)
	local _SoType = so:getTypeName()
 
 
 
		
		if (StaticObject.getByName(_SoName)) and (StaticObject.isExist(so)) then
 

			
			if ( findValue(_tblIncludeStaticObjectType, _SoType)) then
		
				if (_ShowEnvinfo == true) then
					env.info('-- SPGG - Found Red Static Object : '.. _SoName.. ' - Type : ' .. _SoType)
				end
				
		
				if ( findIfValueInArray(_tblExcludeGroupName, _SoName)) then
				
					if (_ShowEnvinfo == true) then
						env.info('-- SPGG - Excluded Red Static Object - On Excluded Name List: ' .. _SoName.. ' - Type : ' .. _SoType)
					end
					

				else
				
					if (_ShowEnvinfo == true) then
						env.info('-- SPGG - Saving Red Static Object: '.. _SoName .. ' - Type : ' .. _SoType)
					end
								
							
					getObjectAndSave(1, _SoName)
					
					
					
				end
			end
		
			
		
		end

	end -- for i, so in pairs(coalition.getStaticObjects(1)) do




	if (ctld ~= nil) then
		saveCtldTables()
	end


	wBackupFile:close()
	wBackupFile  = nil

	wFile:close()
	wFile = nil

end -- end of function SPGGSave(coalitionId)




function getObjectAndSave(coalitionId, soName)

	
		
	if coalitionId ~= nil then
		
		
		
		_sObject = StaticObject.getByName(soName)
		

		local _soType = _sObject:getTypeName()
		
		local _soCoord = _sObject:getPoint()
			
		local _sCoalition = _sObject:getCoalition()
		
		_soPoss = _sObject:getPosition()
		local _soHeading = math.atan2(_soPoss.x.z, _soPoss.x.x)
		
		local _country = _sObject:getCountry()
		
		if coalitionId == 1 then
		
			_soRedCount = _soRedCount +1 
		
			
			
			wFile:write('spgg.redstaticobj['.._soRedCount..'] = { ["obj"] = {} }' .. '\n')
	
			wFile:write('spgg.redstaticobj['.._soRedCount..'].obj[1] = { ["type"] = "' .. _soType .. '", ["name"] = "' .. soName .. '", ["x"] = ' .. _soCoord.x .. ', ["y"] = ' .. _soCoord.z .. ', ["heading"] = ' .. _soHeading .. ', ["country"]= '.. _country ..', }' .. '\n')
		
		
			--Backup
			wBackupFile:write('spgg.redstaticobj['.._soRedCount..'] = { ["obj"] = {} }' .. '\n')
			wBackupFile:write('spgg.redstaticobj['.._soRedCount..'].obj[1] = { ["type"] = "' .. _soType .. '", ["name"] = "' .. soName .. '", ["x"] = ' .. _soCoord.x .. ', ["y"] = ' .. _soCoord.z .. ', ["heading"] = ' .. _soHeading .. ', ["country"]= '.. _country ..', }' .. '\n')
				
		
		elseif coalitionId == 2 then
		
			_soBlueCount = _soBlueCount +1
			
			
			wFile:write('spgg.bluestaticobj['.._soBlueCount..'] = { ["obj"] = {} }' .. '\n')
			
			wFile:write('spgg.bluestaticobj['.._soBlueCount..'].obj[1] = { ["type"] = "' .. _soType .. '", ["name"] = "' .. soName .. '", ["x"] = ' .. _soCoord.x .. ', ["y"] = ' .. _soCoord.z .. ', ["heading"] = ' .. _soHeading .. ', ["country"]= '.. _country ..', }' .. '\n')


			--Backup
			wBackupFile:write('spgg.bluestaticobj['.._soBlueCount..'] = { ["obj"] = {} }' .. '\n')
			wBackupFile:write('spgg.bluestaticobj['.._soBlueCount..'].obj[1] = { ["type"] = "' .. _soType .. '", ["name"] = "' .. soName .. '", ["x"] = ' .. _soCoord.x .. ', ["y"] = ' .. _soCoord.z .. ', ["heading"] = ' .. _soHeading .. ', ["country"]= '.. _country ..', }' .. '\n')


		
		end
	
		
	
	
	end


end








function getGroupAndSave(coalitionId, gpName, gpUnitSize)


	if coalitionId ~= nil then
	
		if coalitionId == 1 then
			
			_groupRedCount = _groupRedCount +1 

			wFile:write('spgg.redgroups['.._groupRedCount..'] = { ["groupname"] = "' ..gpName.. '", ["units"] = {} }' .. '\n')
			
			--backup
			wBackupFile:write('spgg.redgroups['.._groupRedCount..'] = { ["units"] = {} }' .. '\n')
	
		end
	
	
		if coalitionId == 2 then
			
			_groupBlueCount = _groupBlueCount +1 

			wFile:write('spgg.bluegroups['.._groupBlueCount..'] = { ["groupname"] = "' ..gpName.. '", ["units"] = {} }' .. '\n')
			
			--Backup
			wBackupFile:write('spgg.bluegroups['.._groupBlueCount..'] = { ["units"] = {} }' .. '\n')
	
		end




		for uIndex = 1, gpUnitSize do
			
		
		
		
			local _Group = Group.getByName(gpName)
		
			
			local _unitName = _Group:getUnit(uIndex):getName()
		
			local _unit = Unit.getByName(_unitName)
			local _unitType = _unit:getTypeName()
			
			local _unitCoord = _unit:getPoint()
			
			local _coalition = _Group:getCoalition()
				
					
			_unitPoss = _unit:getPosition()
			local _unitHeading = math.atan2(_unitPoss.x.z, _unitPoss.x.x)
			
			
			local _country = _unit:getCountry()
			
		
			if coalitionId == 1 then
		
				if (_ShowEnvinfo == true) then
					env.info('-- SPGG - Saving Red unit: '.. _unitName .. ' - Type: ' .. _unitType .. ' - Coordinates X: ' .. _unitCoord.x .. ' - Y: ' .. _unitCoord.y .. ' - Z: ' .. _unitCoord.z .. ' - Heading: ' .. _unitHeading .. ' - Country: '.. _country)
				end
		
				wFile:write('spgg.redgroups['.._groupRedCount..'].units['..uIndex..'] = { ["type"] = "' .. _unitType .. '", ["skill"] = "Excellent", ["x"] = ' .. _unitCoord.x .. ', ["y"] = ' .. _unitCoord.z .. ', ["heading"] = ' .. _unitHeading .. ', ["playerCanDrive"] = true, ["country"]= '.. _country ..', }' .. '\n')
				
				--backup
				wBackupFile:write('spgg.redgroups['.._groupRedCount..'].units['..uIndex..'] = { ["type"] = "' .. _unitType .. '", ["skill"] = "Excellent", ["x"] = ' .. _unitCoord.x .. ', ["y"] = ' .. _unitCoord.z .. ', ["heading"] = ' .. _unitHeading .. ', ["playerCanDrive"] = true, ["country"]= '.. _country ..', }' .. '\n')
			
	
			
			elseif coalitionId == 2 then
		
				if (_ShowEnvinfo == true) then
					env.info('-- SPGG - Saving Blue unit: '.. _unitName .. ' - Type: ' .. _unitType .. ' - Coordinates X: ' .. _unitCoord.x .. ' - Y: ' .. _unitCoord.y .. ' - Z: ' .. _unitCoord.z .. ' - Heading: ' .. _unitHeading .. ' - Country: '.. _country)
				end
		
				wFile:write('spgg.bluegroups['.._groupBlueCount..'].units['..uIndex..'] = { ["type"] = "' .. _unitType .. '", ["skill"] = "Excellent", ["x"] = ' .. _unitCoord.x .. ', ["y"] = ' .. _unitCoord.z .. ', ["heading"] = ' .. _unitHeading .. ', ["playerCanDrive"] = true, ["country"]= '.. _country ..', }' .. '\n')
			
				--backup
				wBackupFile:write('spgg.bluegroups['.._groupBlueCount..'].units['..uIndex..'] = { ["type"] = "' .. _unitType .. '", ["skill"] = "Excellent", ["x"] = ' .. _unitCoord.x .. ', ["y"] = ' .. _unitCoord.z .. ', ["heading"] = ' .. _unitHeading .. ', ["playerCanDrive"] = true, ["country"]= '.. _country ..', }' .. '\n')
				
			else
		
				if (_ShowEnvinfo == true) then
					env.info('-- SPGG - Failed to get Group Coalition, Neutral? : '.. gpName)
					-- No Neutral units
				end
		
			end
			
		
		end -- for uIndex = 1, gpUnitSize do

		

	end -- end of if coalitionId ~= nil then




	

end -- function getGroupAndSave(gpName, gpUnitSize)




-- Transfere FOB table to next session
function saveCtldTables()


	if (ctld ~= nil) then


		if (ctld.JTAC_dropEnabled ~= nil) then

			if (ctld.JTAC_dropEnabled == true) then
		
			
				-- ctld.JTAC_LIMIT_RED
				-- ctld.JTAC_LIMIT_BLUE
			
				-- ctld.droppedTroopsRED
				-- ctld.droppedTroopsBLUE
			
			
			
				if (_ShowEnvinfo == true) then
					env.info('-- SPGG - Saving JTAC limit parameters - RED :'.. ctld.JTAC_LIMIT_RED .. ' - BLUE: ' .. ctld.JTAC_LIMIT_BLUE)
				end
			
				if (ctld.JTAC_LIMIT_RED ~= nil) and (ctld.JTAC_LIMIT_BLUE ~= nil) then
					wFile:write('ctld.JTAC_LIMIT_RED = '.. ctld.JTAC_LIMIT_RED .. '\n')
					wFile:write('ctld.JTAC_LIMIT_BLUE = '.. ctld.JTAC_LIMIT_BLUE .. '\n')
				
					--backup
					wBackupFile:write('ctld.JTAC_LIMIT_RED = '.. ctld.JTAC_LIMIT_RED .. '\n')
					wBackupFile:write('ctld.JTAC_LIMIT_BLUE = '.. ctld.JTAC_LIMIT_BLUE .. '\n')
				end
				
			
			
			end	 -- end of if (ctld.JTAC_dropEnabled == true) then
		
		end	-- end of if (ctld.JTAC_dropEnabled ~= nil) then
	
	
		if (ctld.droppedTroopsRED ~= nil) and (ctld.droppedTroopsBLUE ~= nil) then

	
			wFile:write('spgg.redtroops = spgg.redtroops or {}' .. '\n')
			wFile:write('spgg.bluetroops = spgg.bluetroops or {}' .. '\n')
		
			--backup
			wBackupFile:write('spgg.redtroops = spgg.redtroops or {}' .. '\n')
			wBackupFile:write('spgg.bluetroops = spgg.bluetroops or {}' .. '\n')
	
	
			for i = 1, #ctld.droppedTroopsRED do
		
		
				
				wFile:write('spgg.redtroops['..i..'] = { ["name"] = "' .. ctld.droppedTroopsRED[i]..'" }' .. '\n')
			
				--backup
				wBackupFile:write('spgg.redtroops['..i..'] = { ["name"] = "' .. ctld.droppedTroopsRED[i]..'" }' .. '\n')
			
			end
		
			for i = 1, #ctld.droppedTroopsBLUE do
		
		
				wFile:write('spgg.bluetroops['..i..'] = { ["name"] = "' .. ctld.droppedTroopsBLUE[i]..'" }' .. '\n')
			
				--backup
				wBackupFile:write('spgg.bluetroops['..i..'] = { ["name"] = "' .. ctld.droppedTroopsBLUE[i]..'" }' .. '\n')
			
			end
	
	
	
		end -- end of if (ctld.droppedTroopsRED ~= nil) and (ctld.droppedTroopsBLUE ~= nil) then
		
		

		
		if (ctld.completeAASystems ~= nil) then
		
			spgg.SaveAASystemDetails()
		
		end -- end of if (ctld.completeAASystems ~= nil) then
		
		
	

	end -- end of if (ctld ~= nil) then


end



function spgg.SaveAASystemDetails()

	
	wFile:write('spgg.completeAASystems = {} \n')
	wBackupFile:write('spgg.completeAASystems = {} \n')

	for _groupName, _hawkDetails in pairs(ctld.completeAASystems) do

		if (_hawkDetails ~= nil) then


			
			wFile:write('spgg.completeAASystems["' .. _groupName .. '"] = {} \n')
			wBackupFile:write('spgg.completeAASystems["' .. _groupName .. '"] = {} \n')
			
			--spgg.completeAASystems[_groupName] = {}
			
			for i = 1, #_hawkDetails do
		
				wFile:write('table.insert(spgg.completeAASystems["'.. _groupName ..'"], {unit= "'.. _hawkDetails[i].unit ..'", name= "'.. _hawkDetails[i].name .. '", pointX= "'.. _hawkDetails[i].point.x .. '", pointY= "'.. _hawkDetails[i].point.y .. '", pointZ= "'.. _hawkDetails[i].point.z .. '", system= "'.. _hawkDetails[i].system.name ..  '" }) \n')
					
				
				--table.insert(spgg.completeAASystems[_groupName], {unit= _hawkDetails[i].unit , name= _hawkDetails[i].name, pointX= _hawkDetails[i].point.x, pointY= _hawkDetails[i].point.y, pointZ= _hawkDetails[i].point.z, system= _hawkDetails[i].system.name })
			
				wBackupFile:write('table.insert(spgg.completeAASystems["'.. _groupName ..'"], {unit= "'.. _hawkDetails[i].unit ..'", name= "'.. _hawkDetails[i].name .. '", pointX= "'.. _hawkDetails[i].point.x .. '", pointY= "'.. _hawkDetails[i].point.y .. '", pointZ= "'.. _hawkDetails[i].point.z .. '", system= "'.. _hawkDetails[i].system.name ..  '" }) \n')
			
			
			end

			

		end

	end


end









-- Loop saving

_spggSaveActive = "1"

function CheckSaveStatus(ourArgument, time)
 -- Do things to check, use ourArgument (which is the scheduleFunction's second argument)
 if ourArgument == 9999 and _spggSaveActive == "1" then

	-- Text saving
	--trigger.action.outText("Timed: Saving Ground Forces" , 10)
	env.info('-- SPGG - Timed: Saving Ground Forces - Start')	
	
	-- Save Ground Forces

	SPGGSave()
	
	env.info('-- SPGG - Timed: Saving Ground Forces - End')
	
	-- Keep going
   return time + 3600
 else
 
 	-- Text saving
	--trigger.action.outText("Timed Last: Saving Ground Forces" , 10)
	 
	env.info('-- SPGG - Timed: Saving schedule has beeb canceled')
	 
	-- Save Ground Forces

	--SPGGSave()
	
	--env.info('-- SPGG - Timed: Saving Ground Forces - End - Timer Schedual ended')
	
	-- That's it we're done looping
   return nil
 end
end


_spggSavetime = 60 * _spggSavetime

timer.scheduleFunction(CheckSaveStatus, 9999, timer.getTime() + _spggSavetime)




env.info('-- SPGG - Loaded Function for Save!')
