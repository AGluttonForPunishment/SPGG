-- Simple Persistent Ground Groups (SPGG)
env.info('-- SPGG : Loading!')
spgg = spgg or {} -- do not remove
_defaultDriveSPGG= lfs.writedir() .. [[Scripts\SPGG\]] 

-- Settings


-- Save loop in min
_spggSavetime = 60

-- Don't show Message box in DCS. Use logg file insted. (_ShowEnvinfo)
env.setErrorMessageBoxEnabled(false)

-- For debugging
_ShowEnvinfo = true	

-- All groups names beginning with strings in this array will be excluded from saveing.
_tblExcludeGroupName = {
"AF_",
"StandAlone_",
"SA_Convoy_"

}

-- All Static Objects with type names in this array will be included when saveing.
_tblIncludeStaticObjectType = {
"outpost",
"house2arm"

}



_saveFunctionsFilename = "SPGG_Save_v013.lua"
_loadFunctionsFilename = "SPGG_load_v013.lua"

_PersistentGroupsSaveFilename = "SPGG_savefile.lua"
--_BackupPersistentGroupsSaveFilename







-- Load Functions
assert(loadfile(_defaultDriveSPGG .. _saveFunctionsFilename))()
assert(loadfile(_defaultDriveSPGG .. _loadFunctionsFilename))()


-- Load Saved Units data (Does not groups spawn on map)
assert(loadfile(_defaultDriveSPGG .. _PersistentGroupsSaveFilename))()