spgg = spgg or {}
spgg.bluegroups = spgg.bluegroups or {}
spgg.redgroups = spgg.redgroups or {}
spgg.bluestaticobj = spgg.bluestaticobj or {}
spgg.redstaticobj = spgg.redstaticobj or {}
spgg.bluegroups[1] = { ["groupname"] = "BlueAiGroundGroup5", ["units"] = {} }
spgg.bluegroups[1].units[1] = { ["type"] = "M-113", ["skill"] = "Excellent", ["x"] = -5559.46875, ["y"] = 242756.078125, ["heading"] = 1.5358897433863, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[2] = { ["type"] = "M-113", ["skill"] = "Excellent", ["x"] = -5648.1416015625, ["y"] = 242783.78125, ["heading"] = 1.5358897433863, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.redgroups[1] = { ["groupname"] = "RedAiGroundGroup6", ["units"] = {} }
spgg.redgroups[1].units[1] = { ["type"] = "BMD-1", ["skill"] = "Excellent", ["x"] = -7292.9370117188, ["y"] = 293914.65625, ["heading"] = 1.5358897433863, ["playerCanDrive"] = true, ["country"]= 0, }
spgg.redgroups[1].units[2] = { ["type"] = "BMP-2", ["skill"] = "Excellent", ["x"] = -7381.6103515625, ["y"] = 293942.375, ["heading"] = 1.5358897433863, ["playerCanDrive"] = true, ["country"]= 0, }
spgg.bluestaticobj[1] = { ["obj"] = {} }
spgg.bluestaticobj[1].obj[1] = { ["type"] = "outpost", ["name"] = "Deployed FOB #7 SPGG Blue", ["x"] = -5567.6176757813, ["y"] = 242763.703125, ["heading"] = 0, ["country"]= 2, }
ctld.JTAC_LIMIT_RED = 10
ctld.JTAC_LIMIT_BLUE = 10
spgg.redtroops = spgg.redtroops or {}
spgg.bluetroops = spgg.bluetroops or {}
spgg.completeAASystems = {} 
