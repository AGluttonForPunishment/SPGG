spgg = spgg or {}
spgg.bluegroups = spgg.bluegroups or {}
spgg.redgroups = spgg.redgroups or {}
spgg.bluestaticobj = spgg.bluestaticobj or {}
spgg.redstaticobj = spgg.redstaticobj or {}
spgg.blueseagroups = spgg.blueseagroups or {}
spgg.redseagroups = spgg.redseagroups or {}
spgg.bluegroups[1] = { ["units"] = {} }
spgg.bluegroups[1].units[1] = { ["type"] = "M-1 Abrams", ["name"] = "Ground-1-6", ["skill"] = "Excellent", ["x"] = 164446.98439422, ["y"] = 107169.79689023, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[2] = { ["type"] = "M-1 Abrams", ["name"] = "Ground-1-7", ["skill"] = "Excellent", ["x"] = 164406.98437993, ["y"] = 107169.79688365, ["heading"] = 3.6378866487865e-12, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[3] = { ["type"] = "M-1 Abrams", ["name"] = "Ground-1-8", ["skill"] = "Excellent", ["x"] = 164366.98443967, ["y"] = 107169.79687934, ["heading"] = -2.9164600115564e-11, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[4] = { ["type"] = "M-1 Abrams", ["name"] = "Ground-1-9", ["skill"] = "Excellent", ["x"] = 164326.98443968, ["y"] = 107169.79687934, ["heading"] = -2.9164624503469e-11, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[5] = { ["type"] = "M-1 Abrams", ["name"] = "Ground-1-10", ["skill"] = "Excellent", ["x"] = 164286.984375, ["y"] = 107169.796875, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[6] = { ["type"] = "M-1 Abrams", ["name"] = "Ground-1-11", ["skill"] = "Excellent", ["x"] = 164246.984375, ["y"] = 107169.796875, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[7] = { ["type"] = "M-1 Abrams", ["name"] = "Ground-1-12", ["skill"] = "Excellent", ["x"] = 164206.984375, ["y"] = 107169.796875, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[8] = { ["type"] = "M-1 Abrams", ["name"] = "Ground-1-13", ["skill"] = "Excellent", ["x"] = 164166.98437501, ["y"] = 107169.796875, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[9] = { ["type"] = "M-1 Abrams", ["name"] = "Ground-1-14", ["skill"] = "Excellent", ["x"] = 164126.984375, ["y"] = 107169.796875, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[10] = { ["type"] = "M-1 Abrams", ["name"] = "Ground-1-15", ["skill"] = "Excellent", ["x"] = 164086.984375, ["y"] = 107169.796875, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[11] = { ["type"] = "LAV-25", ["name"] = "Ground-1-16", ["skill"] = "Excellent", ["x"] = 164046.98437494, ["y"] = 107169.796875, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[12] = { ["type"] = "M-1 Abrams", ["name"] = "Ground-1-17", ["skill"] = "Excellent", ["x"] = 164006.98437499, ["y"] = 107169.796875, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[13] = { ["type"] = "M-1 Abrams", ["name"] = "Ground-1-18", ["skill"] = "Excellent", ["x"] = 163966.984375, ["y"] = 107169.796875, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[14] = { ["type"] = "M-2 Bradley", ["name"] = "Ground-1-19", ["skill"] = "Excellent", ["x"] = 163926.98437512, ["y"] = 107169.796875, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[15] = { ["type"] = "M-2 Bradley", ["name"] = "Ground-1-20", ["skill"] = "Excellent", ["x"] = 163886.98437512, ["y"] = 107169.796875, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[16] = { ["type"] = "LAV-25", ["name"] = "Ground-1-21", ["skill"] = "Excellent", ["x"] = 163846.98437494, ["y"] = 107169.796875, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[17] = { ["type"] = "M-1 Abrams", ["name"] = "Ground-1-22", ["skill"] = "Excellent", ["x"] = 163806.984375, ["y"] = 107169.796875, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[18] = { ["type"] = "M-1 Abrams", ["name"] = "Ground-1-23", ["skill"] = "Excellent", ["x"] = 163766.984375, ["y"] = 107169.796875, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[19] = { ["type"] = "M-1 Abrams", ["name"] = "Ground-1-24", ["skill"] = "Excellent", ["x"] = 163726.984375, ["y"] = 107169.796875, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[20] = { ["type"] = "M-1 Abrams", ["name"] = "Ground-1-25", ["skill"] = "Excellent", ["x"] = 163686.98437501, ["y"] = 107169.796875, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[21] = { ["type"] = "M-1 Abrams", ["name"] = "Ground-1-26", ["skill"] = "Excellent", ["x"] = 163646.984375, ["y"] = 107169.796875, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[22] = { ["type"] = "M-1 Abrams", ["name"] = "Ground-1-27", ["skill"] = "Excellent", ["x"] = 163606.984375, ["y"] = 107169.796875, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
spgg.bluegroups[1].units[23] = { ["type"] = "M-1 Abrams", ["name"] = "Ground-1-28", ["skill"] = "Excellent", ["x"] = 163566.984375, ["y"] = 107169.796875, ["heading"] = 0, ["playerCanDrive"] = true, ["country"]= 2, }
ctld.JTAC_LIMIT_RED = 5
ctld.JTAC_LIMIT_BLUE = 5
spgg.redtroops = spgg.redtroops or {}
spgg.bluetroops = spgg.bluetroops or {}
spgg.completeAASystems = {} 
