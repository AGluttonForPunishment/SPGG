spgg = spgg or {}
spgg.bluegroups = spgg.bluegroups or {}
spgg.redgroups = spgg.redgroups or {}
spgg.bluestaticobj = spgg.bluestaticobj or {}
spgg.redstaticobj = spgg.redstaticobj or {}
spgg.blueseagroups = spgg.blueseagroups or {}
spgg.redseagroups = spgg.redseagroups or {}
spgg.bluestaticobj[1] = { ["obj"] = {} }
spgg.bluestaticobj[1].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2030", ["x"] = 219920.203125, ["y"] = -47107.99609375, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[2] = { ["obj"] = {} }
spgg.bluestaticobj[2].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2031", ["x"] = 219935.0625, ["y"] = -47144.56640625, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[3] = { ["obj"] = {} }
spgg.bluestaticobj[3].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2042", ["x"] = 210372.5, ["y"] = 146821.60938731, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[4] = { ["obj"] = {} }
spgg.bluestaticobj[4].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2043", ["x"] = 210387.359375, ["y"] = 146785.03126231, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[5] = { ["obj"] = {} }
spgg.bluestaticobj[5].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2046", ["x"] = 147665.484375, ["y"] = 39182.128904901, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[6] = { ["obj"] = {} }
spgg.bluestaticobj[6].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2047", ["x"] = 147680.34375, ["y"] = 39145.558596352, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[7] = { ["obj"] = {} }
spgg.bluestaticobj[7].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2048", ["x"] = 222150.703125, ["y"] = -34213.449233931, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[8] = { ["obj"] = {} }
spgg.bluestaticobj[8].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2049", ["x"] = 222165.5625, ["y"] = -34250.019546431, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[9] = { ["obj"] = {} }
spgg.bluestaticobj[9].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2078", ["x"] = 19630.4453125, ["y"] = -234914.87500081, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[10] = { ["obj"] = {} }
spgg.bluestaticobj[10].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2079", ["x"] = 19645.302734375, ["y"] = -234951.453125, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[11] = { ["obj"] = {} }
spgg.bluestaticobj[11].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1010 SPGG Blue", ["x"] = 219920.203125, ["y"] = -47107.99609375, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[12] = { ["obj"] = {} }
spgg.bluestaticobj[12].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1012 SPGG Blue", ["x"] = 219935.0625, ["y"] = -47144.56640625, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[13] = { ["obj"] = {} }
spgg.bluestaticobj[13].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1014 SPGG Blue", ["x"] = 210372.5, ["y"] = 146821.60938731, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[14] = { ["obj"] = {} }
spgg.bluestaticobj[14].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1016 SPGG Blue", ["x"] = 210387.359375, ["y"] = 146785.03126231, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[15] = { ["obj"] = {} }
spgg.bluestaticobj[15].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1018 SPGG Blue", ["x"] = 147665.484375, ["y"] = 39182.128904901, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[16] = { ["obj"] = {} }
spgg.bluestaticobj[16].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1020 SPGG Blue", ["x"] = 147680.34375, ["y"] = 39145.558596352, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[17] = { ["obj"] = {} }
spgg.bluestaticobj[17].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1022 SPGG Blue", ["x"] = 222150.703125, ["y"] = -34213.449233931, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[18] = { ["obj"] = {} }
spgg.bluestaticobj[18].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1024 SPGG Blue", ["x"] = 222165.5625, ["y"] = -34250.019546431, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[19] = { ["obj"] = {} }
spgg.bluestaticobj[19].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1026 SPGG Blue", ["x"] = 19630.4453125, ["y"] = -234914.87500081, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[20] = { ["obj"] = {} }
spgg.bluestaticobj[20].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1028 SPGG Blue", ["x"] = 19645.302734375, ["y"] = -234951.453125, ["heading"] = 0, ["country"]= 2, }
spgg.redstaticobj[1] = { ["obj"] = {} }
spgg.redstaticobj[1].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2028", ["x"] = 76229.515625, ["y"] = 110557.484375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[2] = { ["obj"] = {} }
spgg.redstaticobj[2].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2029", ["x"] = 76244.375, ["y"] = 110520.9140625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[3] = { ["obj"] = {} }
spgg.redstaticobj[3].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2032", ["x"] = -52297.4453125, ["y"] = 61353.7265625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[4] = { ["obj"] = {} }
spgg.redstaticobj[4].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2033", ["x"] = -52282.58984375, ["y"] = 61317.15625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[5] = { ["obj"] = {} }
spgg.redstaticobj[5].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2034", ["x"] = -123911.7890625, ["y"] = 86102.843753133, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[6] = { ["obj"] = {} }
spgg.redstaticobj[6].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2035", ["x"] = -123896.9296875, ["y"] = 86066.273440633, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[7] = { ["obj"] = {} }
spgg.redstaticobj[7].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2036", ["x"] = -257603.734375, ["y"] = 41420.253898467, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[8] = { ["obj"] = {} }
spgg.redstaticobj[8].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2037", ["x"] = -257588.875, ["y"] = 41383.683585967, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[9] = { ["obj"] = {} }
spgg.redstaticobj[9].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2038", ["x"] = -179484.921875, ["y"] = 51880.46875, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[10] = { ["obj"] = {} }
spgg.redstaticobj[10].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2039", ["x"] = -179470.0625, ["y"] = 51843.8984375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[11] = { ["obj"] = {} }
spgg.redstaticobj[11].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2040", ["x"] = -158284.625, ["y"] = 74590.2578125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[12] = { ["obj"] = {} }
spgg.redstaticobj[12].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2041", ["x"] = -158269.765625, ["y"] = 74553.6875, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[13] = { ["obj"] = {} }
spgg.redstaticobj[13].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2044", ["x"] = 8765.5625, ["y"] = 74378.625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[14] = { ["obj"] = {} }
spgg.redstaticobj[14].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2045", ["x"] = 8780.419921875, ["y"] = 74342.0546875, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[15] = { ["obj"] = {} }
spgg.redstaticobj[15].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2050", ["x"] = 115477.03125, ["y"] = 188423.39062081, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[16] = { ["obj"] = {} }
spgg.redstaticobj[16].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2051", ["x"] = 115491.890625, ["y"] = 188386.81249514, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[17] = { ["obj"] = {} }
spgg.redstaticobj[17].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2052", ["x"] = -218271.1875, ["y"] = 57112.839835674, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[18] = { ["obj"] = {} }
spgg.redstaticobj[18].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2053", ["x"] = -218256.328125, ["y"] = 57076.269523174, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[19] = { ["obj"] = {} }
spgg.redstaticobj[19].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2054", ["x"] = 42523.75, ["y"] = 5732.3735351564, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[20] = { ["obj"] = {} }
spgg.redstaticobj[20].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2055", ["x"] = 42538.60546875, ["y"] = 5695.8022460938, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[21] = { ["obj"] = {} }
spgg.redstaticobj[21].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2056", ["x"] = -194198.984375, ["y"] = 45254.3125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[22] = { ["obj"] = {} }
spgg.redstaticobj[22].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2057", ["x"] = -194184.125, ["y"] = 45217.7421875, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[23] = { ["obj"] = {} }
spgg.redstaticobj[23].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2058", ["x"] = -171631.125, ["y"] = 25625.90430098, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[24] = { ["obj"] = {} }
spgg.redstaticobj[24].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2059", ["x"] = -171616.265625, ["y"] = 25589.332029278, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[25] = { ["obj"] = {} }
spgg.redstaticobj[25].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2060", ["x"] = 163891.734375, ["y"] = 106977.46875, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[26] = { ["obj"] = {} }
spgg.redstaticobj[26].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2061", ["x"] = 163906.59375, ["y"] = 106940.8984375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[27] = { ["obj"] = {} }
spgg.redstaticobj[27].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2062", ["x"] = 125619.0234375, ["y"] = 123465.6484375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[28] = { ["obj"] = {} }
spgg.redstaticobj[28].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2063", ["x"] = 125633.8828125, ["y"] = 123429.078125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[29] = { ["obj"] = {} }
spgg.redstaticobj[29].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2064", ["x"] = -55397.359375, ["y"] = 220921.82813074, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[30] = { ["obj"] = {} }
spgg.redstaticobj[30].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2065", ["x"] = -55382.50390625, ["y"] = 220885.25000574, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[31] = { ["obj"] = {} }
spgg.redstaticobj[31].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2066", ["x"] = 125610.0859375, ["y"] = 154534.984375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[32] = { ["obj"] = {} }
spgg.redstaticobj[32].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2067", ["x"] = 125624.9453125, ["y"] = 154498.40625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[33] = { ["obj"] = {} }
spgg.redstaticobj[33].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2068", ["x"] = -151108.59375, ["y"] = 117337.6484375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[34] = { ["obj"] = {} }
spgg.redstaticobj[34].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2069", ["x"] = -151093.734375, ["y"] = 117301.078125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[35] = { ["obj"] = {} }
spgg.redstaticobj[35].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2070", ["x"] = -60775.26171875, ["y"] = 89552.6015625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[36] = { ["obj"] = {} }
spgg.redstaticobj[36].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2071", ["x"] = -60760.40625, ["y"] = 89516.03125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[37] = { ["obj"] = {} }
spgg.redstaticobj[37].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2072", ["x"] = 77120.71875, ["y"] = 242838.390625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[38] = { ["obj"] = {} }
spgg.redstaticobj[38].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2073", ["x"] = 77135.578125, ["y"] = 242801.8125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[39] = { ["obj"] = {} }
spgg.redstaticobj[39].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2074", ["x"] = -58768.78515625, ["y"] = 158312.609375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[40] = { ["obj"] = {} }
spgg.redstaticobj[40].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2075", ["x"] = -58753.9296875, ["y"] = 158276.03125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[41] = { ["obj"] = {} }
spgg.redstaticobj[41].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2076", ["x"] = -8237.5859375, ["y"] = -209690.90625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[42] = { ["obj"] = {} }
spgg.redstaticobj[42].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2077", ["x"] = -8222.728515625, ["y"] = -209727.484375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[43] = { ["obj"] = {} }
spgg.redstaticobj[43].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2080", ["x"] = 31792.158203125, ["y"] = -197720.87500139, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[44] = { ["obj"] = {} }
spgg.redstaticobj[44].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2081", ["x"] = 31807.015625, ["y"] = -197757.45312639, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[45] = { ["obj"] = {} }
spgg.redstaticobj[45].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1030 SPGG Red", ["x"] = 76229.515625, ["y"] = 110557.484375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[46] = { ["obj"] = {} }
spgg.redstaticobj[46].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1032 SPGG Red", ["x"] = 76244.375, ["y"] = 110520.9140625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[47] = { ["obj"] = {} }
spgg.redstaticobj[47].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1034 SPGG Red", ["x"] = -52297.4453125, ["y"] = 61353.7265625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[48] = { ["obj"] = {} }
spgg.redstaticobj[48].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1036 SPGG Red", ["x"] = -52282.58984375, ["y"] = 61317.15625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[49] = { ["obj"] = {} }
spgg.redstaticobj[49].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1038 SPGG Red", ["x"] = -123911.7890625, ["y"] = 86102.843753133, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[50] = { ["obj"] = {} }
spgg.redstaticobj[50].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1040 SPGG Red", ["x"] = -123896.9296875, ["y"] = 86066.273440633, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[51] = { ["obj"] = {} }
spgg.redstaticobj[51].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1042 SPGG Red", ["x"] = -257603.734375, ["y"] = 41420.253898467, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[52] = { ["obj"] = {} }
spgg.redstaticobj[52].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1044 SPGG Red", ["x"] = -257588.875, ["y"] = 41383.683585967, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[53] = { ["obj"] = {} }
spgg.redstaticobj[53].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1046 SPGG Red", ["x"] = -179484.921875, ["y"] = 51880.46875, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[54] = { ["obj"] = {} }
spgg.redstaticobj[54].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1048 SPGG Red", ["x"] = -179470.0625, ["y"] = 51843.8984375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[55] = { ["obj"] = {} }
spgg.redstaticobj[55].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1050 SPGG Red", ["x"] = -158284.625, ["y"] = 74590.2578125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[56] = { ["obj"] = {} }
spgg.redstaticobj[56].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1052 SPGG Red", ["x"] = -158269.765625, ["y"] = 74553.6875, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[57] = { ["obj"] = {} }
spgg.redstaticobj[57].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1054 SPGG Red", ["x"] = 8765.5625, ["y"] = 74378.625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[58] = { ["obj"] = {} }
spgg.redstaticobj[58].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1056 SPGG Red", ["x"] = 8780.419921875, ["y"] = 74342.0546875, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[59] = { ["obj"] = {} }
spgg.redstaticobj[59].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1058 SPGG Red", ["x"] = 115477.03125, ["y"] = 188423.39062081, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[60] = { ["obj"] = {} }
spgg.redstaticobj[60].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1060 SPGG Red", ["x"] = 115491.890625, ["y"] = 188386.81249514, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[61] = { ["obj"] = {} }
spgg.redstaticobj[61].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1062 SPGG Red", ["x"] = -218271.1875, ["y"] = 57112.839835674, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[62] = { ["obj"] = {} }
spgg.redstaticobj[62].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1064 SPGG Red", ["x"] = -218256.328125, ["y"] = 57076.269523174, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[63] = { ["obj"] = {} }
spgg.redstaticobj[63].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1066 SPGG Red", ["x"] = 42523.75, ["y"] = 5732.3735351564, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[64] = { ["obj"] = {} }
spgg.redstaticobj[64].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1068 SPGG Red", ["x"] = 42538.60546875, ["y"] = 5695.8022460938, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[65] = { ["obj"] = {} }
spgg.redstaticobj[65].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1070 SPGG Red", ["x"] = -194198.984375, ["y"] = 45254.3125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[66] = { ["obj"] = {} }
spgg.redstaticobj[66].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1072 SPGG Red", ["x"] = -194184.125, ["y"] = 45217.7421875, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[67] = { ["obj"] = {} }
spgg.redstaticobj[67].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1074 SPGG Red", ["x"] = -171631.125, ["y"] = 25625.90430098, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[68] = { ["obj"] = {} }
spgg.redstaticobj[68].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1076 SPGG Red", ["x"] = -171616.265625, ["y"] = 25589.332029278, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[69] = { ["obj"] = {} }
spgg.redstaticobj[69].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1078 SPGG Red", ["x"] = 163891.734375, ["y"] = 106977.46875, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[70] = { ["obj"] = {} }
spgg.redstaticobj[70].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1080 SPGG Red", ["x"] = 163906.59375, ["y"] = 106940.8984375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[71] = { ["obj"] = {} }
spgg.redstaticobj[71].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1082 SPGG Red", ["x"] = 125619.0234375, ["y"] = 123465.6484375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[72] = { ["obj"] = {} }
spgg.redstaticobj[72].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1084 SPGG Red", ["x"] = 125633.8828125, ["y"] = 123429.078125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[73] = { ["obj"] = {} }
spgg.redstaticobj[73].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1086 SPGG Red", ["x"] = -55397.359375, ["y"] = 220921.82813074, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[74] = { ["obj"] = {} }
spgg.redstaticobj[74].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1088 SPGG Red", ["x"] = -55382.50390625, ["y"] = 220885.25000574, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[75] = { ["obj"] = {} }
spgg.redstaticobj[75].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1090 SPGG Red", ["x"] = 125610.0859375, ["y"] = 154534.984375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[76] = { ["obj"] = {} }
spgg.redstaticobj[76].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1092 SPGG Red", ["x"] = 125624.9453125, ["y"] = 154498.40625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[77] = { ["obj"] = {} }
spgg.redstaticobj[77].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1094 SPGG Red", ["x"] = -151108.59375, ["y"] = 117337.6484375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[78] = { ["obj"] = {} }
spgg.redstaticobj[78].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1096 SPGG Red", ["x"] = -151093.734375, ["y"] = 117301.078125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[79] = { ["obj"] = {} }
spgg.redstaticobj[79].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1098 SPGG Red", ["x"] = -60775.26171875, ["y"] = 89552.6015625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[80] = { ["obj"] = {} }
spgg.redstaticobj[80].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1100 SPGG Red", ["x"] = -60760.40625, ["y"] = 89516.03125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[81] = { ["obj"] = {} }
spgg.redstaticobj[81].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1102 SPGG Red", ["x"] = 77120.71875, ["y"] = 242838.390625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[82] = { ["obj"] = {} }
spgg.redstaticobj[82].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1104 SPGG Red", ["x"] = 77135.578125, ["y"] = 242801.8125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[83] = { ["obj"] = {} }
spgg.redstaticobj[83].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1106 SPGG Red", ["x"] = -58768.78515625, ["y"] = 158312.609375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[84] = { ["obj"] = {} }
spgg.redstaticobj[84].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1108 SPGG Red", ["x"] = -58753.9296875, ["y"] = 158276.03125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[85] = { ["obj"] = {} }
spgg.redstaticobj[85].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1110 SPGG Red", ["x"] = -8237.5859375, ["y"] = -209690.90625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[86] = { ["obj"] = {} }
spgg.redstaticobj[86].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1112 SPGG Red", ["x"] = -8222.728515625, ["y"] = -209727.484375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[87] = { ["obj"] = {} }
spgg.redstaticobj[87].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #1114 SPGG Red", ["x"] = 31792.158203125, ["y"] = -197720.87500139, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[88] = { ["obj"] = {} }
spgg.redstaticobj[88].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "Deployed FOB #1116 SPGG Red", ["x"] = 31807.015625, ["y"] = -197757.45312639, ["heading"] = 0, ["country"]= 0, }
ctld.JTAC_LIMIT_RED = 5
ctld.JTAC_LIMIT_BLUE = 5
spgg.redtroops = spgg.redtroops or {}
spgg.bluetroops = spgg.bluetroops or {}
spgg.completeAASystems = {} 
