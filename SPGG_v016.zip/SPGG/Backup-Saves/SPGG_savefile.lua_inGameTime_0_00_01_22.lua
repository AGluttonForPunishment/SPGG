spgg = spgg or {}
spgg.bluegroups = spgg.bluegroups or {}
spgg.redgroups = spgg.redgroups or {}
spgg.bluestaticobj = spgg.bluestaticobj or {}
spgg.redstaticobj = spgg.redstaticobj or {}
spgg.blueseagroups = spgg.blueseagroups or {}
spgg.redseagroups = spgg.redseagroups or {}
spgg.bluestaticobj[1] = { ["obj"] = {} }
spgg.bluestaticobj[1].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2065", ["x"] = 219920.203125, ["y"] = -47107.99609375, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[2] = { ["obj"] = {} }
spgg.bluestaticobj[2].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2066", ["x"] = 219935.0625, ["y"] = -47144.56640625, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[3] = { ["obj"] = {} }
spgg.bluestaticobj[3].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2125", ["x"] = 210372.5, ["y"] = 146821.60938731, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[4] = { ["obj"] = {} }
spgg.bluestaticobj[4].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2126", ["x"] = 210387.359375, ["y"] = 146785.03126231, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[5] = { ["obj"] = {} }
spgg.bluestaticobj[5].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2138", ["x"] = 147665.484375, ["y"] = 39182.128904901, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[6] = { ["obj"] = {} }
spgg.bluestaticobj[6].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2139", ["x"] = 147680.34375, ["y"] = 39145.558596352, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[7] = { ["obj"] = {} }
spgg.bluestaticobj[7].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2140", ["x"] = 222150.703125, ["y"] = -34213.449233931, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[8] = { ["obj"] = {} }
spgg.bluestaticobj[8].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2141", ["x"] = 222165.5625, ["y"] = -34250.019546431, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[9] = { ["obj"] = {} }
spgg.bluestaticobj[9].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2287", ["x"] = 19630.4453125, ["y"] = -234914.87500081, ["heading"] = 0, ["country"]= 2, }
spgg.bluestaticobj[10] = { ["obj"] = {} }
spgg.bluestaticobj[10].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2288", ["x"] = 19645.302734375, ["y"] = -234951.453125, ["heading"] = 0, ["country"]= 2, }
spgg.redstaticobj[1] = { ["obj"] = {} }
spgg.redstaticobj[1].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2063", ["x"] = 76229.515625, ["y"] = 110557.484375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[2] = { ["obj"] = {} }
spgg.redstaticobj[2].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2064", ["x"] = 76244.375, ["y"] = 110520.9140625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[3] = { ["obj"] = {} }
spgg.redstaticobj[3].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2073", ["x"] = -52297.4453125, ["y"] = 61353.7265625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[4] = { ["obj"] = {} }
spgg.redstaticobj[4].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2074", ["x"] = -52282.58984375, ["y"] = 61317.15625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[5] = { ["obj"] = {} }
spgg.redstaticobj[5].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2085", ["x"] = -123911.7890625, ["y"] = 86102.843753133, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[6] = { ["obj"] = {} }
spgg.redstaticobj[6].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2086", ["x"] = -123896.9296875, ["y"] = 86066.273440633, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[7] = { ["obj"] = {} }
spgg.redstaticobj[7].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2102", ["x"] = -257603.734375, ["y"] = 41420.253898467, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[8] = { ["obj"] = {} }
spgg.redstaticobj[8].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2103", ["x"] = -257588.875, ["y"] = 41383.683585967, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[9] = { ["obj"] = {} }
spgg.redstaticobj[9].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2113", ["x"] = -179484.921875, ["y"] = 51880.46875, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[10] = { ["obj"] = {} }
spgg.redstaticobj[10].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2114", ["x"] = -179470.0625, ["y"] = 51843.8984375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[11] = { ["obj"] = {} }
spgg.redstaticobj[11].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2123", ["x"] = -158284.625, ["y"] = 74590.2578125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[12] = { ["obj"] = {} }
spgg.redstaticobj[12].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2124", ["x"] = -158269.765625, ["y"] = 74553.6875, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[13] = { ["obj"] = {} }
spgg.redstaticobj[13].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2136", ["x"] = 8765.5625, ["y"] = 74378.625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[14] = { ["obj"] = {} }
spgg.redstaticobj[14].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2137", ["x"] = 8780.419921875, ["y"] = 74342.0546875, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[15] = { ["obj"] = {} }
spgg.redstaticobj[15].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2148", ["x"] = 115477.03125, ["y"] = 188423.39062081, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[16] = { ["obj"] = {} }
spgg.redstaticobj[16].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2149", ["x"] = 115491.890625, ["y"] = 188386.81249514, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[17] = { ["obj"] = {} }
spgg.redstaticobj[17].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2160", ["x"] = -218271.1875, ["y"] = 57112.839835674, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[18] = { ["obj"] = {} }
spgg.redstaticobj[18].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2161", ["x"] = -218256.328125, ["y"] = 57076.269523174, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[19] = { ["obj"] = {} }
spgg.redstaticobj[19].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2172", ["x"] = 42523.75, ["y"] = 5732.3735351564, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[20] = { ["obj"] = {} }
spgg.redstaticobj[20].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2173", ["x"] = 42538.60546875, ["y"] = 5695.8022460938, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[21] = { ["obj"] = {} }
spgg.redstaticobj[21].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2182", ["x"] = -194198.984375, ["y"] = 45254.3125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[22] = { ["obj"] = {} }
spgg.redstaticobj[22].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2183", ["x"] = -194184.125, ["y"] = 45217.7421875, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[23] = { ["obj"] = {} }
spgg.redstaticobj[23].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2193", ["x"] = -171631.125, ["y"] = 25625.90430098, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[24] = { ["obj"] = {} }
spgg.redstaticobj[24].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2194", ["x"] = -171616.265625, ["y"] = 25589.332029278, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[25] = { ["obj"] = {} }
spgg.redstaticobj[25].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2208", ["x"] = 125619.0234375, ["y"] = 123465.6484375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[26] = { ["obj"] = {} }
spgg.redstaticobj[26].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2209", ["x"] = 125633.8828125, ["y"] = 123429.078125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[27] = { ["obj"] = {} }
spgg.redstaticobj[27].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2220", ["x"] = -55397.359375, ["y"] = 220921.82813074, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[28] = { ["obj"] = {} }
spgg.redstaticobj[28].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2221", ["x"] = -55382.50390625, ["y"] = 220885.25000574, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[29] = { ["obj"] = {} }
spgg.redstaticobj[29].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2232", ["x"] = 125610.0859375, ["y"] = 154534.984375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[30] = { ["obj"] = {} }
spgg.redstaticobj[30].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2233", ["x"] = 125624.9453125, ["y"] = 154498.40625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[31] = { ["obj"] = {} }
spgg.redstaticobj[31].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2243", ["x"] = -151108.59375, ["y"] = 117337.6484375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[32] = { ["obj"] = {} }
spgg.redstaticobj[32].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2244", ["x"] = -151093.734375, ["y"] = 117301.078125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[33] = { ["obj"] = {} }
spgg.redstaticobj[33].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2255", ["x"] = -60775.26171875, ["y"] = 89552.6015625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[34] = { ["obj"] = {} }
spgg.redstaticobj[34].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2256", ["x"] = -60760.40625, ["y"] = 89516.03125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[35] = { ["obj"] = {} }
spgg.redstaticobj[35].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2265", ["x"] = 77120.71875, ["y"] = 242838.390625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[36] = { ["obj"] = {} }
spgg.redstaticobj[36].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2266", ["x"] = 77135.578125, ["y"] = 242801.8125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[37] = { ["obj"] = {} }
spgg.redstaticobj[37].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2276", ["x"] = -58768.78515625, ["y"] = 158312.609375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[38] = { ["obj"] = {} }
spgg.redstaticobj[38].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2277", ["x"] = -58753.9296875, ["y"] = 158276.03125, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[39] = { ["obj"] = {} }
spgg.redstaticobj[39].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2285", ["x"] = -8237.5859375, ["y"] = -209690.90625, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[40] = { ["obj"] = {} }
spgg.redstaticobj[40].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2286", ["x"] = -8222.728515625, ["y"] = -209727.484375, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[41] = { ["obj"] = {} }
spgg.redstaticobj[41].obj[1] = { ["type"] = "outpost", ["category"] = "4", ["name"] = "Deployed FOB #2300", ["x"] = 31792.158203125, ["y"] = -197720.87500139, ["heading"] = 0, ["country"]= 0, }
spgg.redstaticobj[42] = { ["obj"] = {} }
spgg.redstaticobj[42].obj[1] = { ["type"] = "house2arm", ["category"] = "4", ["name"] = "FOB Watchtower #2301", ["x"] = 31807.015625, ["y"] = -197757.45312639, ["heading"] = 0, ["country"]= 0, }
ctld.JTAC_LIMIT_RED = 5
ctld.JTAC_LIMIT_BLUE = 5
spgg.redtroops = spgg.redtroops or {}
spgg.bluetroops = spgg.bluetroops or {}
spgg.completeAASystems = {} 
