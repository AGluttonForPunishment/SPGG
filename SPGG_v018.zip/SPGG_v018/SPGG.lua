-- Simple Persistent Ground Groups (SPGG)
-- By A Glutton For Punishment (aka Kanelbolle)

env.info('-- SPGG v018 : Loading!')
spgg = spgg or {} -- do not remove
spgg.defaultDrive = lfs.writedir() .. [[Scripts\SPGG_v018\]] 

env.info('-- SPGG Dir: ' .. spgg.defaultDrive)
-- Settings


-- Save loop in min
spgg.Savetime = 60

-- Reuse GroupNames from save file
-- (If names exist the group will overwrite the existing unit, recommended to be false if mission is not designed for this)
spgg.ReuseGroupNames = false

-- Reuse Unit Names from save file
-- (If names exist the unit will overwrite or not spawn, recommended to be false if mission is not designed for this)
spgg.ReuseUnitNames = false

-- If "True", only the Ground groups and Sea groups that  are active in the Mission are saved. (Static objects are not inclided in the check)
spgg.saveOnlyActiveGroups = true


-- Don't show Message box in DCS. Use logg file insted. (_ShowEnvinfo)
env.setErrorMessageBoxEnabled(false)

-- For debugging
spgg.showEnvinfo = true	

-- All groups names beginning with strings in this array will be excluded from saveing.
_tblExcludeGroupName = {
"AF_",
"StandAlone_",
"SA_Convoy_"

}

-- All Static Objects with type names in this array will be included when saveing.
_tblIncludeStaticObjectType = {
"outpost",
"house2arm",
"WindTurbine"

}



spgg.saveFunctionsFilename = "SPGG_Save_v018.lua"
spgg.loadFunctionsFilename = "SPGG_load_v018.lua"

spgg.saveFilename = "SPGG_savefile.lua"
--_BackupPersistentGroupsSaveFilename







-- Load Functions
assert(loadfile(spgg.defaultDrive .. spgg.saveFunctionsFilename))()
assert(loadfile(spgg.defaultDrive .. spgg.loadFunctionsFilename))()


-- Load Saved Units data (Does not groups spawn on map)
assert(loadfile(spgg.defaultDrive .. spgg.saveFilename))()